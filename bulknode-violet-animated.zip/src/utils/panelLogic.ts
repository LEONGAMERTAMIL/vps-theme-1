export type ServerStatus = 'RUNNING' | 'STARTING' | 'STOPPING' | 'RESTARTING' | 'OFFLINE';
export type ServerCategory = 'minecraft' | 'bot';

export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'CMD';
  source: string;
  message: string;
}

export interface ServerFile {
  name: string;
  type: 'folder' | 'file';
  size: string;
  modified: string;
  content?: string;
}

export interface StartupVariable {
  key: string;
  name: string;
  description: string;
  value: string;
  rules: string;
}

export interface DatabaseItem {
  id: string;
  name: string;
  username: string;
  host: string;
  connectionsFrom: string;
  maxConnections: number;
}

export interface BackupItem {
  id: string;
  name: string;
  size: string;
  createdAt: string;
  sha256: string;
  locked: boolean;
}

export interface ScheduleItem {
  id: string;
  name: string;
  cron: string;
  lastRun: string;
  nextRun: string;
  active: boolean;
  tasksCount: number;
}

export interface SubuserItem {
  id: string;
  username: string;
  email: string;
  role: string;
  twoFactor: boolean;
  permissions: number;
}

export interface AllocationItem {
  id: string;
  ip: string;
  alias: string;
  port: number;
  notes: string;
  isPrimary: boolean;
}

export interface PluginItem {
  id: string;
  name: string;
  category: 'minecraft' | 'bot';
  author: string;
  downloads: string;
  version: string;
  description: string;
  installed: boolean;
}

export interface EggOption {
  id: string;
  name: string;
  category: ServerCategory;
  dockerImage: string;
  description: string;
  startupCommand: string;
}

export interface ServerInstance {
  id: string;
  shortId: string;
  name: string;
  category: ServerCategory;
  eggId: string;
  eggName: string;
  node: string;
  countryCode: string;
  hostname: string;
  ip: string;
  port: number;
  status: ServerStatus;
  uptime: string;
  cpuPercent: number;
  cpuCores: number;
  cpuHistory: number[];
  memoryUsedGB: number;
  memoryLimitGB: number;
  memoryHistory: number[];
  diskUsedGB: number;
  diskLimitGB: number;
  netInBps: number;
  netOutBps: number;
  netHistory: number[];
  billingPlan: string;
  logs: LogEntry[];
  files: ServerFile[];
  startupCommand: string;
  dockerImage: string;
  variables: StartupVariable[];
  databases: DatabaseItem[];
  backups: BackupItem[];
  schedules: ScheduleItem[];
  subusers: SubuserItem[];
  allocations: AllocationItem[];
  subdomain: string;
}

export const EGG_CATALOG: EggOption[] = [
  {
    id: 'egg-papermc',
    name: 'PaperMC 1.21.4 (High Performance MC)',
    category: 'minecraft',
    dockerImage: 'ghcr.io/pterodactyl/yolks:java_21',
    description: 'Next-generation high performance Minecraft server with Async chunk loading and Spigot/Bukkit plugin support.',
    startupCommand: 'java -Xms128M -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -jar {{SERVER_JARFILE}} nogui',
  },
  {
    id: 'egg-purpur',
    name: 'Purpur 1.21.4 (Fork of Paper)',
    category: 'minecraft',
    dockerImage: 'ghcr.io/pterodactyl/yolks:java_21',
    description: 'Drop-in replacement for Paper servers designed for configurability, fun gameplay features, and top TPS.',
    startupCommand: 'java -Xms128M -XX:+UseG1GC -XX:G1HeapRegionSize=8M -jar purpur.jar nogui',
  },
  {
    id: 'egg-velocity',
    name: 'Velocity 3.3.0 Proxy Network',
    category: 'minecraft',
    dockerImage: 'ghcr.io/pterodactyl/yolks:java_21',
    description: 'Modern, blazing fast Minecraft proxy server engineered for large multi-node networks.',
    startupCommand: 'java -Xms512M -Xmx{{SERVER_MEMORY}}M -XX:+UseG1GC -jar velocity.jar',
  },
  {
    id: 'egg-discordjs',
    name: 'Discord.js v14 / Node.js 22 LTS',
    category: 'bot',
    dockerImage: 'ghcr.io/pterodactyl/yolks:nodejs_22',
    description: 'Production Node.js 22 runtime with TypeScript, Sharding Manager, and native voice/Lavalink support for Discord bots.',
    startupCommand: 'npm install && node {{BOT_JS_FILE}}',
  },
  {
    id: 'egg-discordpy',
    name: 'Discord.py 2.4 / Python 3.12',
    category: 'bot',
    dockerImage: 'ghcr.io/pterodactyl/yolks:python_3.12',
    description: 'Async Python 3.12 container with uv/pip auto-install for AI, moderation, and utility Discord bots.',
    startupCommand: 'pip install -U -r requirements.txt && python3 {{PY_FILE}}',
  },
  {
    id: 'egg-lavalink',
    name: 'Lavalink v4 Audio Cluster Node',
    category: 'bot',
    dockerImage: 'ghcr.io/lavalink-devs/lavalink:4',
    description: 'Standalone audio sending node based on Lavaplayer for high-concurrency Discord music bots.',
    startupCommand: 'java -Xmx{{SERVER_MEMORY}}M -jar Lavalink.jar',
  },
];

export const PLUGIN_CATALOG: PluginItem[] = [
  {
    id: 'pl-essentialsx',
    name: 'EssentialsX + Spawn',
    category: 'minecraft',
    author: 'EssentialsX Team',
    downloads: '4.8M',
    version: '2.21.0-dev',
    description: 'The essential plugin suite for Minecraft servers, with over 130 commands, economy, warps, and kits.',
    installed: true,
  },
  {
    id: 'pl-luckperms',
    name: 'LuckPerms',
    category: 'minecraft',
    author: 'Luck',
    downloads: '6.2M',
    version: '5.4.145',
    description: 'Fast, reliable permissions plugin with live Web Editor, SQL/MongoDB sync, and context inheritance.',
    installed: true,
  },
  {
    id: 'pl-vault',
    name: 'Vault Economy API',
    category: 'minecraft',
    author: 'MilkBowl',
    downloads: '9.1M',
    version: '1.7.3',
    description: 'Permissions, Chat, & Economy API to give plugins easy hooks into server systems.',
    installed: true,
  },
  {
    id: 'pl-worldedit',
    name: 'FastAsyncWorldEdit (FAWE)',
    category: 'minecraft',
    author: 'IntellectualSites',
    downloads: '3.4M',
    version: '2.11.2',
    description: 'Blazingly fast world manipulation and schematic pasting without lagging server TPS.',
    installed: false,
  },
  {
    id: 'pl-spark',
    name: 'spark Profiler',
    category: 'minecraft',
    author: 'lucko',
    downloads: '2.9M',
    version: '1.10.109',
    description: 'Performance profiler for Minecraft servers, clients, and proxies with flamegraphs.',
    installed: true,
  },
  {
    id: 'pl-geyser',
    name: 'GeyserMC + Floodgate (Bedrock Crossplay)',
    category: 'minecraft',
    author: 'GeyserMC',
    downloads: '5.1M',
    version: '2.4.2-b680',
    description: 'Enable Minecraft Bedrock Edition clients to join your Java Edition server seamlessly.',
    installed: false,
  },
  {
    id: 'pl-shoukaku',
    name: 'Kazagumo + Shoukaku Lavalink v4',
    category: 'bot',
    author: 'Deivu',
    downloads: '890K',
    version: '4.1.0',
    description: 'Low-latency Lavalink v4 wrapper for Discord.js with automatic node failover and Spotify/Apple Music resolver.',
    installed: true,
  },
  {
    id: 'pl-sapphire',
    name: 'Sapphire Command Framework',
    category: 'bot',
    author: 'SapphireDev',
    downloads: '1.4M',
    version: '5.2.1',
    description: 'Next-gen object-oriented Discord.js bot framework with slash command auto-registration and precondition guards.',
    installed: false,
  },
];

export const INITIAL_SERVERS: ServerInstance[] = [
  {
    id: 'srv-hunter-stock',
    shortId: 'a8f3921c',
    name: 'Hunter Custom Stock Plan',
    category: 'minecraft',
    eggId: 'egg-papermc',
    eggName: 'PaperMC 1.21.4 (High Performance MC)',
    node: 'In - Node 25 - Premium - Epyc 9',
    countryCode: 'IN',
    hostname: 'paid25.bulknode.com:25574',
    ip: '103.195.102.25',
    port: 25574,
    status: 'RUNNING',
    uptime: '1d 18h 3m 12s',
    cpuPercent: 4.9,
    cpuCores: 10,
    cpuHistory: [4.2, 4.5, 4.8, 5.1, 4.7, 5.2, 4.9, 4.6, 5.0, 4.9, 5.2, 4.9],
    memoryUsedGB: 4.36,
    memoryLimitGB: 62.7,
    memoryHistory: [4.28, 4.30, 4.32, 4.35, 4.35, 4.36, 4.36, 4.38, 4.36, 4.36, 4.37, 4.36],
    diskUsedGB: 6.74,
    diskLimitGB: 146.5,
    netInBps: 240,
    netOutBps: 810,
    netHistory: [420, 510, 620, 490, 730, 890, 640, 780, 910, 820, 790, 810],
    billingPlan: 'Custom EPYC 9654 Dedicated Stock Plan (Unmetered NVMe)',
    subdomain: 'play.huntercraft.bulknode.gg',
    startupCommand: 'java -Xms128M -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -jar server.jar nogui',
    dockerImage: 'ghcr.io/pterodactyl/yolks:java_21',
    logs: [
      { id: 'l-1', timestamp: '21:20:01', level: 'WARN', source: 'AutoUpdatePlugins', message: 'Failed to download or extract plugin: Connect timed out' },
      { id: 'l-2', timestamp: '21:20:11', level: 'WARN', source: 'AutoUpdatePlugins', message: 'Failed to download or extract plugin: Connect timed out' },
      { id: 'l-3', timestamp: '21:20:22', level: 'INFO', source: 'AutoUpdatePlugins', message: 'Download for AutoUpdatePlugins was not successful' },
      { id: 'l-4', timestamp: '23:19:50', level: 'INFO', source: 'AutoUpdatePlugins', message: 'AutoUpdatePlugins ---- https://github.com/NewAmazingPVP/AutoUpdatePlugins' },
      { id: 'l-5', timestamp: '03:19:25', level: 'INFO', source: 'Vault', message: 'Checking for Updates ...' },
      { id: 'l-6', timestamp: '03:19:25', level: 'INFO', source: 'Vault', message: 'No new version available' },
      { id: 'l-7', timestamp: '03:20:01', level: 'WARN', source: 'AutoUpdatePlugins', message: 'Failed to download or extract plugin: Connect timed out' },
      { id: 'l-8', timestamp: '04:19:25', level: 'ERROR', source: 'ajLeaderboards', message: '** CRITICAL ALERT ** BulkNode Guard isolated suspicious bytecode in ajLeaderboards/cache.jar — quarantined safely.' },
      { id: 'l-9', timestamp: '05:19:50', level: 'INFO', source: 'AutoUpdatePlugins', message: 'AutoUpdatePlugins ---- https://github.com/NewAmazingPVP/AutoUpdatePlugins' },
      { id: 'l-10', timestamp: '09:19:25', level: 'INFO', source: 'Vault', message: 'Checking for Updates ...' },
      { id: 'l-11', timestamp: '09:19:25', level: 'INFO', source: 'Vault', message: 'No new version available' },
      { id: 'l-12', timestamp: '09:20:10', level: 'INFO', source: 'BulkNode-Wings', message: 'Daemon heartbeat verified on In-Node-25 (EPYC 9654) — TPS: 20.00 / MSPT: 4.1ms' },
    ],
    files: [
      { name: 'plugins', type: 'folder', size: '412.8 MB', modified: '2 hours ago' },
      { name: 'world', type: 'folder', size: '4.12 GB', modified: '4 minutes ago' },
      { name: 'world_nether', type: 'folder', size: '1.28 GB', modified: '12 minutes ago' },
      { name: 'world_the_end', type: 'folder', size: '840.2 MB', modified: '35 minutes ago' },
      { name: 'config', type: 'folder', size: '14.2 MB', modified: '1 day ago' },
      {
        name: 'server.properties',
        type: 'file',
        size: '4.2 KB',
        modified: '3 hours ago',
        content: `#Minecraft server properties\n#Managed by BulkNode Panel\nmotd=\\u00A7c\\u00A7lB\\u1D1C\\u029F\\u1D0B\\u004E\\u1D0F\\u1D05\\u1D07 \\u00A78| \\u00A7fFast & Reliable Hosting \\uD83D\\uDE80\nserver-port=25574\nmax-players=250\nview-distance=10\nsimulation-distance=8\nonline-mode=true\nenable-query=true\npvp=true\ndifficulty=hard\nlevel-name=world`,
      },
      {
        name: 'spigot.yml',
        type: 'file',
        size: '6.8 KB',
        modified: '2 days ago',
        content: `config-version: 12\nsettings:\n  debug: false\n  bungeecord: true\n  netty-threads: 8\nworld-settings:\n  default:\n    merge-radius:\n      item: 3.5\n      exp: 6.0`,
      },
      { name: 'server.jar', type: 'file', size: '48.6 MB', modified: '5 days ago' },
      { name: 'eula.txt', type: 'file', size: '182 B', modified: '2 weeks ago', content: 'eula=true\n' },
    ],
    variables: [
      { key: 'SERVER_JARFILE', name: 'Server Jar File', description: 'The name of the server jarfile to run the server with.', value: 'server.jar', rules: 'required|regex:/^([\\w\\d._-]+)(\\.jar)$/' },
      { key: 'MINECRAFT_VERSION', name: 'Minecraft Version', description: 'The version of PaperMC to download on reinstall.', value: '1.21.4', rules: 'required|string|max:20' },
      { key: 'BUILD_NUMBER', name: 'Build Number', description: 'The PaperMC build number (leave as latest for automatic updates).', value: 'latest', rules: 'required|string' },
      { key: 'JVM_FLAGS', name: 'Aikar / ZGC Flags', description: 'Additional JVM garbage collection flags.', value: '-XX:+UseG1GC -XX:+ParallelRefProcEnabled', rules: 'nullable|string' },
    ],
    databases: [
      { id: 'db-1', name: 's25574_luckperms', username: 'u25574_k9x2p', host: 'db-in25.bulknode.com:3306', connectionsFrom: '%', maxConnections: 100 },
      { id: 'db-2', name: 's25574_coreprotect', username: 'u25574_m3v8q', host: 'db-in25.bulknode.com:3306', connectionsFrom: '103.195.102.25', maxConnections: 50 },
    ],
    backups: [
      { id: 'bk-1', name: 'Pre-Season-4-Reset-Snapshot', size: '3.82 GB', createdAt: 'Today at 04:00 AM', sha256: '9f86d081884c7d659a2feaa0c55ad015', locked: true },
      { id: 'bk-2', name: 'Automated Daily NVMe Backup', size: '4.11 GB', createdAt: 'Yesterday at 04:00 AM', sha256: '4b227777d4dd1fc61c6f884f48641d02', locked: false },
    ],
    schedules: [
      { id: 'sch-1', name: 'Daily 4AM Server Restart & Trim', cron: '0 4 * * *', lastRun: '7 hours ago', nextRun: 'in 17 hours', active: true, tasksCount: 3 },
      { id: 'sch-2', name: 'Hourly World Save-All', cron: '0 * * * *', lastRun: '22 minutes ago', nextRun: 'in 38 minutes', active: true, tasksCount: 1 },
    ],
    subusers: [
      { id: 'usr-1', username: 'hunterk.v', email: 'contactallsaved@gmail.com', role: 'Root Owner', twoFactor: true, permissions: 42 },
      { id: 'usr-2', username: 'dev_arjun', email: 'arjun.mc@bulknode.gg', role: 'Lead Developer', twoFactor: true, permissions: 28 },
    ],
    allocations: [
      { id: 'al-1', ip: '103.195.102.25', alias: 'paid25.bulknode.com', port: 25574, notes: 'Primary Minecraft Game Port', isPrimary: true },
      { id: 'al-2', ip: '103.195.102.25', alias: 'paid25.bulknode.com', port: 24454, notes: 'Simple Voice Chat UDP', isPrimary: false },
      { id: 'al-3', ip: '103.195.102.25', alias: 'paid25.bulknode.com', port: 8100, notes: 'BlueMap 3D Web Render', isPrimary: false },
    ],
  },
  {
    id: 'srv-bulkbot-prime',
    shortId: 'b7e4109a',
    name: 'BulkBot Prime | Music & Moderation 🚀',
    category: 'bot',
    eggId: 'egg-discordjs',
    eggName: 'Discord.js v14 / Node.js 22 LTS',
    node: 'SG - Node 04 - Ryzen 9 7950X',
    countryCode: 'SG',
    hostname: 'bot04.bulknode.com:9042',
    ip: '15.235.180.14',
    port: 9042,
    status: 'RUNNING',
    uptime: '6d 11h 49m',
    cpuPercent: 1.8,
    cpuCores: 4,
    cpuHistory: [1.4, 1.6, 1.9, 1.5, 2.1, 1.7, 1.8, 1.6, 1.9, 1.7, 1.8, 1.8],
    memoryUsedGB: 0.64,
    memoryLimitGB: 8.0,
    memoryHistory: [0.58, 0.60, 0.61, 0.62, 0.63, 0.64, 0.63, 0.64, 0.64, 0.65, 0.64, 0.64],
    diskUsedGB: 1.18,
    diskLimitGB: 30.0,
    netInBps: 520,
    netOutBps: 1420,
    netHistory: [800, 950, 1120, 1340, 1280, 1410, 1390, 1500, 1420, 1380, 1450, 1420],
    billingPlan: 'Bot Pro NVMe Cluster — ₹199/mo',
    subdomain: 'api.bulkbot.bulknode.gg',
    startupCommand: 'npm install && node src/index.js',
    dockerImage: 'ghcr.io/pterodactyl/yolks:nodejs_22',
    logs: [
      { id: 'bl-1', timestamp: '10:00:01', level: 'INFO', source: 'ShardManager', message: 'Spawned 4/4 Gateway Shards via Discord WebSocket v10 (Latency: 19ms)' },
      { id: 'bl-2', timestamp: '10:00:04', level: 'INFO', source: 'Lavalink-v4', message: 'Connected to BulkNode-Audio-IN1 & SG1 (28 active voice players)' },
      { id: 'bl-3', timestamp: '10:14:22', level: 'INFO', source: 'AutoMod', message: 'Blocked phishing invite link in guild #general (742,190 total members protected)' },
      { id: 'bl-4', timestamp: '10:29:15', level: 'INFO', source: 'SlashEngine', message: 'Synchronized 68 application (/) commands globally' },
    ],
    files: [
      { name: 'src', type: 'folder', size: '2.4 MB', modified: '1 day ago' },
      { name: 'node_modules', type: 'folder', size: '312.0 MB', modified: '6 days ago' },
      {
        name: 'config.json',
        type: 'file',
        size: '1.8 KB',
        modified: '1 day ago',
        content: `{\n  "botName": "BulkBot Prime 🚀",\n  "prefix": "!",\n  "shards": "auto",\n  "lavalinkNodes": [\n    { "host": "audio-in1.bulknode.com", "port": 2333, "secure": true }\n  ]\n}`,
      },
      {
        name: 'package.json',
        type: 'file',
        size: '1.1 KB',
        modified: '6 days ago',
        content: `{\n  "name": "bulkbot-prime",\n  "version": "4.2.0",\n  "main": "src/index.js",\n  "dependencies": {\n    "discord.js": "^14.16.3",\n    "kazagumo": "^3.2.1"\n  }\n}`,
      },
    ],
    variables: [
      { key: 'BOT_JS_FILE', name: 'Main Bot Entry File', description: 'The main JavaScript file executed by Node.js.', value: 'src/index.js', rules: 'required|string' },
      { key: 'NODE_PACKAGES', name: 'Additional NPM Packages', description: 'Space-separated list of npm packages to install on boot.', value: 'discord.js kazagumo shoukaku', rules: 'nullable|string' },
    ],
    databases: [
      { id: 'db-b1', name: 's9042_guildconfig', username: 'u9042_bot', host: 'db-sg04.bulknode.com:3306', connectionsFrom: '%', maxConnections: 50 },
    ],
    backups: [
      { id: 'bk-b1', name: 'Bot v4.2 Release Snapshot', size: '48.2 MB', createdAt: '3 days ago', sha256: 'c4ca4238a0b923820dcc509a6f75849b', locked: true },
    ],
    schedules: [
      { id: 'sch-b1', name: 'Weekly Memory Cache Flush', cron: '0 0 * * 0', lastRun: '4 days ago', nextRun: 'in 3 days', active: true, tasksCount: 1 },
    ],
    subusers: [
      { id: 'usr-b1', username: 'hunterk.v', email: 'contactallsaved@gmail.com', role: 'Root Owner', twoFactor: true, permissions: 42 },
    ],
    allocations: [
      { id: 'al-b1', ip: '15.235.180.14', alias: 'bot04.bulknode.com', port: 9042, notes: 'Webhook & OAuth Callback Port', isPrimary: true },
    ],
  },
  {
    id: 'srv-lifesteal-network',
    shortId: 'c5d9284e',
    name: 'Crimson Lifesteal SMP [Season 5]',
    category: 'minecraft',
    eggId: 'egg-purpur',
    eggName: 'Purpur 1.21.4 (Fork of Paper)',
    node: 'DE - Node 11 - Ryzen 9 9950X',
    countryCode: 'DE',
    hostname: 'de11.bulknode.com:25565',
    ip: '138.201.94.11',
    port: 25565,
    status: 'RUNNING',
    uptime: '4d 09h 18m',
    cpuPercent: 18.4,
    cpuCores: 8,
    cpuHistory: [16.2, 17.5, 19.0, 18.1, 17.8, 18.9, 18.4, 19.2, 18.0, 18.5, 18.2, 18.4],
    memoryUsedGB: 14.2,
    memoryLimitGB: 32.0,
    memoryHistory: [13.8, 13.9, 14.0, 14.1, 14.1, 14.2, 14.2, 14.3, 14.2, 14.2, 14.2, 14.2],
    diskUsedGB: 28.9,
    diskLimitGB: 120.0,
    netInBps: 1840,
    netOutBps: 4920,
    netHistory: [3900, 4100, 4500, 4300, 4800, 5100, 4700, 4950, 4890, 4920, 4900, 4920],
    billingPlan: 'Extreme Ryzen 9950X 32GB Plan',
    subdomain: 'lifesteal.bulknode.gg',
    startupCommand: 'java -Xms128M -XX:+UseG1GC -XX:G1HeapRegionSize=8M -jar purpur.jar nogui',
    dockerImage: 'ghcr.io/pterodactyl/yolks:java_21',
    logs: [
      { id: 'll-1', timestamp: '12:01:10', level: 'INFO', source: 'Purpur', message: 'Done (3.412s)! For help, type "help"' },
      { id: 'll-2', timestamp: '12:04:55', level: 'INFO', source: 'LifestealCore', message: 'Player xShadowKing eliminated ViperMC (+1 Heart transferred)' },
      { id: 'll-3', timestamp: '12:09:12', level: 'INFO', source: 'Spark', message: 'TPS from last 1m, 5m, 15m: *20.0, *20.0, *20.0' },
    ],
    files: [
      { name: 'plugins', type: 'folder', size: '286.4 MB', modified: '1 hour ago' },
      { name: 'world', type: 'folder', size: '19.4 GB', modified: '1 minute ago' },
      { name: 'purpur.yml', type: 'file', size: '12.4 KB', modified: '4 days ago', content: 'verbose: false\nconfig-version: 34\nsettings:\n  server-mod-name: BulkNode-Purpur' },
    ],
    variables: [
      { key: 'SERVER_JARFILE', name: 'Server Jar File', description: 'Jarfile to execute.', value: 'purpur.jar', rules: 'required|string' },
    ],
    databases: [],
    backups: [],
    schedules: [],
    subusers: [],
    allocations: [
      { id: 'al-l1', ip: '138.201.94.11', alias: 'de11.bulknode.com', port: 25565, notes: 'Primary Dedicated IP Port', isPrimary: true },
    ],
  },
];

export function filterServers(
  servers: ServerInstance[],
  searchQuery: string,
  categoryFilter: 'all' | ServerCategory
): ServerInstance[] {
  const normalizedQuery = searchQuery.trim().toLowerCase();
  return servers.filter((server) => {
    const matchesCategory = categoryFilter === 'all' || server.category === categoryFilter;
    if (!matchesCategory) return false;
    if (!normalizedQuery) return true;
    return (
      server.name.toLowerCase().includes(normalizedQuery) ||
      server.node.toLowerCase().includes(normalizedQuery) ||
      server.hostname.toLowerCase().includes(normalizedQuery) ||
      server.eggName.toLowerCase().includes(normalizedQuery) ||
      server.shortId.toLowerCase().includes(normalizedQuery)
    );
  });
}

export function calculateResourceMetrics(server: ServerInstance) {
  const memoryPercentage = server.memoryLimitGB > 0
    ? Math.min(100, Math.round((server.memoryUsedGB / server.memoryLimitGB) * 1000) / 10)
    : 0;
  const diskPercentage = server.diskLimitGB > 0
    ? Math.min(100, Math.round((server.diskUsedGB / server.diskLimitGB) * 100))
    : 0;
  const diskFreeGB = Math.max(0, Math.round((server.diskLimitGB - server.diskUsedGB) * 100) / 100);
  const cpuMaxScale = server.cpuCores * 100;
  const cpuPercentage =
    server.cpuPercent > 100 && cpuMaxScale > 0
      ? Math.min(100, Math.round((server.cpuPercent / cpuMaxScale) * 1000) / 10)
      : Math.min(100, Math.round(server.cpuPercent * 10) / 10);

  const isOffline = server.status === 'OFFLINE';
  const isCpuCritical = !isOffline && (server.cpuPercent > 90 || cpuPercentage > 90);
  const isMemoryCritical = !isOffline && memoryPercentage > 90;
  const isHighLoadWarning = isCpuCritical || isMemoryCritical;

  return {
    memoryPercentage,
    diskPercentage,
    diskFreeGB,
    cpuMaxScale,
    cpuPercentage,
    isCpuCritical,
    isMemoryCritical,
    isHighLoadWarning,
  };
}

export function toggleSimulatedLoadSpike(
  server: ServerInstance,
  enableSpike: boolean
): ServerInstance {
  if (enableSpike) {
    const spikedCpu = 94.8;
    const spikedMem = Math.round(server.memoryLimitGB * 0.94 * 100) / 100;
    return {
      ...server,
      status: 'RUNNING',
      cpuPercent: spikedCpu,
      cpuHistory: [...server.cpuHistory.slice(1), spikedCpu],
      memoryUsedGB: spikedMem,
      memoryHistory: [...server.memoryHistory.slice(1), spikedMem],
    };
  }

  const normalCpu = server.id === 'srv-hunter-stock' ? 4.9 : 6.5;
  const normalMem =
    server.id === 'srv-hunter-stock'
      ? 4.36
      : Math.round(server.memoryLimitGB * 0.25 * 100) / 100;

  return {
    ...server,
    cpuPercent: normalCpu,
    cpuHistory: [...server.cpuHistory.slice(1), normalCpu],
    memoryUsedGB: normalMem,
    memoryHistory: [...server.memoryHistory.slice(1), normalMem],
  };
}

export function transitionPowerState(
  currentStatus: ServerStatus,
  action: 'start' | 'restart' | 'stop' | 'kill'
): { intermediateStatus: ServerStatus; finalStatus: ServerStatus; systemMessage: string } {
  switch (action) {
    case 'start':
      return {
        intermediateStatus: 'STARTING',
        finalStatus: 'RUNNING',
        systemMessage: 'Container initialized by BulkNode Wings Daemon. Server marked as RUNNING.',
      };
    case 'restart':
      return {
        intermediateStatus: 'RESTARTING',
        finalStatus: 'RUNNING',
        systemMessage: 'Graceful restart sequence completed. All sockets rebound cleanly.',
      };
    case 'stop':
      return {
        intermediateStatus: 'STOPPING',
        finalStatus: 'OFFLINE',
        systemMessage: 'Saved world chunks & flushed buffers. Container stopped cleanly.',
      };
    case 'kill':
      return {
        intermediateStatus: 'OFFLINE',
        finalStatus: 'OFFLINE',
        systemMessage: 'SIGKILL sent to container process. Instance terminated immediately.',
      };
  }
}

export function executeConsoleCommand(
  server: ServerInstance,
  rawCommand: string
): LogEntry[] {
  const trimmed = rawCommand.trim();
  if (!trimmed) return [];

  const now = new Date();
  const timestamp = now.toTimeString().slice(0, 8);
  const cmdEntry: LogEntry = {
    id: `cmd-${Date.now()}-1`,
    timestamp,
    level: 'CMD',
    source: 'Console',
    message: `> ${trimmed}`,
  };

  const lower = trimmed.toLowerCase();
  let responseMessage = '';
  let responseSource = server.category === 'minecraft' ? 'Server thread/INFO' : 'BotCluster';
  let responseLevel: LogEntry['level'] = 'INFO';

  if (server.status === 'OFFLINE') {
    return [
      cmdEntry,
      {
        id: `cmd-${Date.now()}-2`,
        timestamp,
        level: 'WARN',
        source: 'BulkNode-Daemon',
        message: 'Cannot dispatch command: Server container is currently OFFLINE. Press Start first.',
      },
    ];
  }

  if (lower === 'help' || lower === '?') {
    responseMessage =
      server.category === 'minecraft'
        ? 'Available commands: tps, list, plugins, version, save-all, say <msg>, op <player>, whitelist, timings, spark'
        : 'Available bot CLI commands: status, shards, guilds, deploy-commands, lavalink, reload, memory';
  } else if (lower === 'tps' || lower === 'spark tps') {
    responseSource = 'Spark';
    responseMessage = 'TPS from last 5s, 1m, 5m, 15m: *20.00, *20.00, *20.00, *19.99 (MSPT: 3.8ms / 50.0ms)';
  } else if (lower === 'list' || lower === 'online') {
    responseMessage =
      server.category === 'minecraft'
        ? 'There are 42 of a max of 250 players online: HUNTER, xShadowKing, ArjunMC, BulkNode_Admin, Vaitheeswaran...'
        : 'Connected across 1,420 Discord servers | 4/4 Shards READY | 28 active voice channels.';
  } else if (lower === 'plugins' || lower === 'pl') {
    responseMessage = 'Server Plugins (14): LuckPerms, Vault, EssentialsX, EssentialsSpawn, FastAsyncWorldEdit, spark, CoreProtect, ajLeaderboards, AutoUpdatePlugins, DeluxeMenus, PlaceholderAPI, Citizens, WorldGuard, BulkNodeGuard';
  } else if (lower === 'version' || lower === 'ver') {
    responseMessage =
      server.category === 'minecraft'
        ? 'This server is running Paper version 1.21.4-212-main@a8f3921 (2026-11-12) (Implementing API version 1.21.4-R0.1-SNAPSHOT)'
        : 'Runtime: Node.js v22.11.0 LTS | Discord.js v14.16.3 | BulkNode Container v3.8';
  } else if (lower.startsWith('say ')) {
    const text = trimmed.slice(4);
    responseMessage = `[Server] ${text}`;
  } else if (lower === 'save-all') {
    responseMessage = 'ThreadedAnvilChunkStorage: Saved 1,842 chunks across world, world_nether, world_the_end in 42ms.';
  } else {
    responseMessage = `Executed "${trimmed}" successfully on ${server.name} (0 errors).`;
  }

  return [
    cmdEntry,
    {
      id: `cmd-${Date.now()}-2`,
      timestamp,
      level: responseLevel,
      source: responseSource,
      message: responseMessage,
    },
  ];
}

export function validateNewServerInput(input: {
  name: string;
  eggId: string;
  memoryLimitGB: number;
  diskLimitGB: number;
  cpuCores: number;
}): { valid: boolean; error?: string } {
  if (!input.name || input.name.trim().length < 3) {
    return { valid: false, error: 'Instance name must be at least 3 characters long.' };
  }
  const egg = EGG_CATALOG.find((e) => e.id === input.eggId);
  if (!egg) {
    return { valid: false, error: 'Please select a valid server Egg.' };
  }
  if (input.memoryLimitGB < 1 || input.memoryLimitGB > 128) {
    return { valid: false, error: 'Memory allocation must be between 1 GB and 128 GB.' };
  }
  if (input.diskLimitGB < 5 || input.diskLimitGB > 1000) {
    return { valid: false, error: 'NVMe Disk allocation must be between 5 GB and 1000 GB.' };
  }
  if (input.cpuCores < 1 || input.cpuCores > 32) {
    return { valid: false, error: 'CPU core allocation must be between 1 and 32 cores.' };
  }
  return { valid: true };
}

export function parseUptimeToSeconds(uptimeStr: string): number {
  if (!uptimeStr || uptimeStr === 'Offline' || uptimeStr === '0s' || uptimeStr === '0m') {
    return 0;
  }
  let total = 0;
  const daysMatch = uptimeStr.match(/(\d+)\s*d/i);
  const hoursMatch = uptimeStr.match(/(\d+)\s*h/i);
  const minutesMatch = uptimeStr.match(/(\d+)\s*m/i);
  const secondsMatch = uptimeStr.match(/(\d+)\s*s/i);

  if (daysMatch) total += parseInt(daysMatch[1], 10) * 86400;
  if (hoursMatch) total += parseInt(hoursMatch[1], 10) * 3600;
  if (minutesMatch) total += parseInt(minutesMatch[1], 10) * 60;
  if (secondsMatch) total += parseInt(secondsMatch[1], 10);

  return total;
}

export function formatUptime(totalSeconds: number): string {
  const safeSeconds = Math.max(0, Math.floor(totalSeconds));
  if (safeSeconds === 0) return '0s';

  const days = Math.floor(safeSeconds / 86400);
  const hours = Math.floor((safeSeconds % 86400) / 3600);
  const minutes = Math.floor((safeSeconds % 3600) / 60);
  const seconds = safeSeconds % 60;

  const parts: string[] = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0 || days > 0) parts.push(`${hours}h`);
  if (minutes > 0 || hours > 0 || days > 0) parts.push(`${minutes}m`);
  parts.push(`${seconds}s`);

  return parts.join(' ');
}

export function incrementUptime(currentUptime: string, deltaSeconds = 3): string {
  const currentSec = parseUptimeToSeconds(currentUptime);
  return formatUptime(currentSec + Math.max(0, deltaSeconds));
}

export interface TelemetryDataPoint {
  tick: string;
  cpu: number;
  memoryGB: number;
  netOutBps: number;
  netInBps: number;
}

export function buildTelemetryChartData(server: ServerInstance): TelemetryDataPoint[] {
  const length = Math.max(
    server.cpuHistory.length,
    server.netHistory.length,
    server.memoryHistory.length
  );
  if (length === 0) return [];

  const isOffline = server.status === 'OFFLINE';
  const points: TelemetryDataPoint[] = [];

  for (let i = 0; i < length; i++) {
    const secondsAgo = (length - 1 - i) * 2;
    const tick = secondsAgo === 0 ? 'Now' : `-${secondsAgo}s`;
    const cpuVal = isOffline
      ? 0
      : server.cpuHistory[i] ?? server.cpuPercent ?? 0;
    const memVal = isOffline
      ? 0
      : server.memoryHistory[i] ?? server.memoryUsedGB ?? 0;
    const netOutVal = isOffline
      ? 0
      : server.netHistory[i] ?? server.netOutBps ?? 0;
    const netInVal = isOffline
      ? 0
      : Math.max(40, Math.round(netOutVal * 0.34));

    points.push({
      tick,
      cpu: Number(cpuVal.toFixed(1)),
      memoryGB: Number(memVal.toFixed(2)),
      netOutBps: Math.round(netOutVal),
      netInBps: netInVal,
    });
  }

  return points;
}

export type QuickActionType = 'clear_cache' | 'backup_now' | 'update_plugins' | 'save_world';

export interface QuickActionResult {
  updatedServer: ServerInstance;
  toastMessage: string;
  actionSummary: string;
}

export function executeQuickAction(
  server: ServerInstance,
  action: QuickActionType
): QuickActionResult {
  const now = new Date();
  const timestamp = now.toTimeString().slice(0, 8);

  if (action === 'clear_cache') {
    const freedMemGB =
      server.status === 'OFFLINE'
        ? 0
        : Number(Math.max(0.15, server.memoryUsedGB * 0.12).toFixed(2));
    const nextMemoryUsedGB =
      server.status === 'OFFLINE'
        ? 0
        : Number(Math.max(0.25, server.memoryUsedGB - freedMemGB).toFixed(2));
    const nextDiskUsedGB = Number(Math.max(0.5, server.diskUsedGB - 0.12).toFixed(2));
    const nextMemoryHistory = [...server.memoryHistory.slice(1), nextMemoryUsedGB];

    const logEntry: LogEntry = {
      id: `qa-cache-${Date.now()}`,
      timestamp,
      level: 'INFO',
      source: 'BulkNodeDaemon',
      message: `Quick Action [Clear Cache]: Purged /cache & temporary artifacts (-0.12 GB disk) and freed ${freedMemGB.toFixed(2)} GB heap memory.`,
    };

    return {
      updatedServer: {
        ...server,
        memoryUsedGB: nextMemoryUsedGB,
        memoryHistory: nextMemoryHistory,
        diskUsedGB: nextDiskUsedGB,
        logs: [...server.logs, logEntry],
      },
      toastMessage: `Cleared cache on ${server.name} (freed ${freedMemGB.toFixed(2)} GB RAM & 120 MB disk)`,
      actionSummary: `Freed ${freedMemGB.toFixed(2)} GB RAM`,
    };
  }

  if (action === 'backup_now') {
    const snapshotSizeGB = Math.max(0.8, Number((server.diskUsedGB * 0.48).toFixed(2)));
    const newBackup: BackupItem = {
      id: `bkp-quick-${Date.now()}`,
      name: `Quick Snapshot (${timestamp})`,
      size: `${snapshotSizeGB} GB`,
      createdAt: 'Just now',
      sha256: `e3b0c44298fc1c149afbf4c8996fb924${Math.floor(100000 + Math.random() * 899999)}`,
      locked: false,
    };

    const logEntry: LogEntry = {
      id: `qa-backup-${Date.now()}`,
      timestamp,
      level: 'INFO',
      source: 'BackupDaemon',
      message: `Quick Action [Backup Now]: Created instant NVMe snapshot "${newBackup.name}" (${newBackup.size}) with SHA-256 verification.`,
    };

    const updatedBackups = [newBackup, ...server.backups];

    return {
      updatedServer: {
        ...server,
        backups: updatedBackups,
        logs: [...server.logs, logEntry],
      },
      toastMessage: `Created instant backup "${newBackup.name}" (${newBackup.size})`,
      actionSummary: `${updatedBackups.length} snapshots stored`,
    };
  }

  if (action === 'update_plugins') {
    const scanLog: LogEntry = {
      id: `qa-plugins-1-${Date.now()}`,
      timestamp,
      level: 'INFO',
      source: 'AutoUpdatePlugins',
      message:
        server.category === 'minecraft'
          ? 'Quick Action [Update Plugins]: Checking 14 installed PaperMC/Purpur plugins against BulkNode FastMirror...'
          : 'Quick Action [Update Plugins]: Checking Discord.js & Lavalink bot modules against registry...',
    };

    const doneLog: LogEntry = {
      id: `qa-plugins-2-${Date.now()}`,
      timestamp,
      level: 'INFO',
      source: 'AutoUpdatePlugins',
      message:
        server.category === 'minecraft'
          ? 'Successfully updated LuckPerms (v5.4.145), Vault (v1.7.3), EssentialsX (v2.21.0), spark (v1.10.109), and ajLeaderboards (v2.9.2-patched).'
          : 'Successfully updated discord.js (v14.16.3), lavalink-client (v2.4.1), and @bulknode/shard-manager to latest stable release.',
    };

    return {
      updatedServer: {
        ...server,
        logs: [...server.logs, scanLog, doneLog],
      },
      toastMessage: `Updated all installed ${
        server.category === 'minecraft' ? 'Minecraft plugins' : 'bot modules'
      } on ${server.name}`,
      actionSummary: 'All plugins up-to-date',
    };
  }

  // 'save_world'
  const saveLog: LogEntry = {
    id: `qa-save-${Date.now()}`,
    timestamp,
    level: 'INFO',
    source: server.category === 'minecraft' ? 'Server thread' : 'ShardManager',
    message:
      server.category === 'minecraft'
        ? 'Quick Action [Flush & Save World]: ThreadedAnvilChunkStorage saved 1,842 chunks across world, world_nether, world_the_end in 31ms.'
        : 'Quick Action [Sync Shard State]: Flushed guild cache & voice session state to NVMe storage in 14ms.',
  };

  return {
    updatedServer: {
      ...server,
      logs: [...server.logs, saveLog],
    },
    toastMessage: `Flushed & saved live state to NVMe disk on ${server.name}`,
    actionSummary: 'Synced in 31ms',
  };
}
