import test from 'node:test';
import assert from 'node:assert/strict';
import {
  INITIAL_SERVERS,
  filterServers,
  calculateResourceMetrics,
  transitionPowerState,
  executeConsoleCommand,
  validateNewServerInput,
  parseUptimeToSeconds,
  formatUptime,
  incrementUptime,
  toggleSimulatedLoadSpike,
  buildTelemetryChartData,
  executeQuickAction,
} from './panelLogic';

test('filterServers filters by search query and category accurately', () => {
  const all = filterServers(INITIAL_SERVERS, '', 'all');
  assert.equal(all.length, 3);

  const mcOnly = filterServers(INITIAL_SERVERS, '', 'minecraft');
  assert.equal(mcOnly.length, 2);

  const botOnly = filterServers(INITIAL_SERVERS, '', 'bot');
  assert.equal(botOnly.length, 1);
  assert.equal(botOnly[0].id, 'srv-bulkbot-prime');

  const hunterSearch = filterServers(INITIAL_SERVERS, 'Hunter Custom', 'all');
  assert.equal(hunterSearch.length, 1);
  assert.equal(hunterSearch[0].hostname, 'paid25.bulknode.com:25574');
});

test('calculateResourceMetrics computes accurate percentages and free disk matching Hunter Stock Plan', () => {
  const hunter = INITIAL_SERVERS[0];
  const metrics = calculateResourceMetrics(hunter);
  assert.equal(metrics.diskPercentage, 5);
  assert.equal(metrics.diskFreeGB, 139.76);
  assert.equal(metrics.cpuMaxScale, 1000);
  assert.equal(metrics.isHighLoadWarning, false);
});

test('calculateResourceMetrics triggers warning flags when CPU or RAM exceeds 90%', () => {
  const hunter = INITIAL_SERVERS[0];
  const spiked = toggleSimulatedLoadSpike(hunter, true);
  const spikedMetrics = calculateResourceMetrics(spiked);
  assert.equal(spikedMetrics.isCpuCritical, true);
  assert.equal(spikedMetrics.isMemoryCritical, true);
  assert.equal(spikedMetrics.isHighLoadWarning, true);

  const normalized = toggleSimulatedLoadSpike(spiked, false);
  const normalMetrics = calculateResourceMetrics(normalized);
  assert.equal(normalMetrics.isHighLoadWarning, false);
});

test('transitionPowerState returns deterministic intermediate and final states', () => {
  const stopResult = transitionPowerState('RUNNING', 'stop');
  assert.equal(stopResult.intermediateStatus, 'STOPPING');
  assert.equal(stopResult.finalStatus, 'OFFLINE');

  const restartResult = transitionPowerState('RUNNING', 'restart');
  assert.equal(restartResult.intermediateStatus, 'RESTARTING');
  assert.equal(restartResult.finalStatus, 'RUNNING');
});

test('executeConsoleCommand returns command echo and realistic server response', () => {
  const hunter = INITIAL_SERVERS[0];
  const logs = executeConsoleCommand(hunter, 'tps');
  assert.equal(logs.length, 2);
  assert.equal(logs[0].level, 'CMD');
  assert.ok(logs[1].message.includes('20.00'));
});

test('validateNewServerInput validates required server parameters', () => {
  const invalidName = validateNewServerInput({
    name: 'ab',
    eggId: 'egg-papermc',
    memoryLimitGB: 8,
    diskLimitGB: 40,
    cpuCores: 4,
  });
  assert.equal(invalidName.valid, false);

  const validServer = validateNewServerInput({
    name: 'BulkNode BedWars #1',
    eggId: 'egg-papermc',
    memoryLimitGB: 16,
    diskLimitGB: 80,
    cpuCores: 6,
  });
  assert.equal(validServer.valid, true);
});

test('uptime helpers parse, format, and increment running server uptime accurately', () => {
  const secs = parseUptimeToSeconds('1d 18h 3m 12s');
  assert.equal(secs, 86400 + 18 * 3600 + 3 * 60 + 12);
  assert.equal(formatUptime(secs), '1d 18h 3m 12s');
  assert.equal(incrementUptime('1d 18h 3m 12s', 1), '1d 18h 3m 13s');
  assert.equal(incrementUptime('1d 18h 3m 59s', 1), '1d 18h 4m 0s');
});

test('buildTelemetryChartData transforms CPU and Network history into Recharts series', () => {
  const hunter = INITIAL_SERVERS[0];
  const series = buildTelemetryChartData(hunter);
  assert.equal(series.length, hunter.cpuHistory.length);
  assert.equal(series[series.length - 1].tick, 'Now');
  assert.equal(series[series.length - 1].cpu, 4.9);
  assert.equal(series[series.length - 1].netOutBps, 810);
});

test('executeQuickAction performs Clear Cache, Backup Now, and Update Plugins state updates', () => {
  const hunter = INITIAL_SERVERS[0];

  const cacheRes = executeQuickAction(hunter, 'clear_cache');
  assert.ok(cacheRes.updatedServer.memoryUsedGB < hunter.memoryUsedGB);
  assert.ok(cacheRes.updatedServer.diskUsedGB < hunter.diskUsedGB);
  assert.equal(cacheRes.updatedServer.logs.length, hunter.logs.length + 1);

  const backupRes = executeQuickAction(hunter, 'backup_now');
  assert.equal(backupRes.updatedServer.backups.length, hunter.backups.length + 1);
  assert.ok(backupRes.updatedServer.backups[0].name.startsWith('Quick Snapshot'));

  const pluginRes = executeQuickAction(hunter, 'update_plugins');
  assert.equal(pluginRes.updatedServer.logs.length, hunter.logs.length + 2);
  assert.ok(pluginRes.toastMessage.includes('Updated all installed'));
});
