import React, { useState, useRef, useEffect } from 'react';
import {
  Cpu,
  HardDrive,
  MemoryStick,
  Network,
  Play,
  RotateCw,
  Square,
  Power,
  Copy,
  Check,
  Search,
  History,
  Server,
  CreditCard,
  Loader2,
  Terminal as TerminalIcon,
  AlertTriangle,
  Flame,
  Activity,
  Zap,
  Trash2,
  Archive,
  RefreshCw,
  Save,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import {
  ServerInstance,
  calculateResourceMetrics,
  toggleSimulatedLoadSpike,
  buildTelemetryChartData,
  executeQuickAction,
  QuickActionType,
} from '../utils/panelLogic';

interface ServerOverviewAndConsoleProps {
  server: ServerInstance;
  mode: 'overview' | 'console';
  onPowerAction: (action: 'start' | 'restart' | 'stop' | 'kill') => void;
  powerLoading: 'start' | 'restart' | 'stop' | 'kill' | null;
  onSendCommand: (command: string) => void;
  onShowToast: (msg: string) => void;
  onUpdateServer?: (updated: ServerInstance) => void;
}

export const ServerOverviewAndConsole: React.FC<ServerOverviewAndConsoleProps> = ({
  server,
  mode,
  onPowerAction,
  powerLoading,
  onSendCommand,
  onShowToast,
  onUpdateServer,
}) => {
  const [commandInput, setCommandInput] = useState('');
  const [commandHistory, setCommandHistory] = useState<string[]>(['tps', 'list', 'plugins']);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [logFilter, setLogFilter] = useState('');
  const [showLogSearch, setShowLogSearch] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [runningQuickAction, setRunningQuickAction] = useState<QuickActionType | null>(null);
  const [quickActionStatus, setQuickActionStatus] = useState<{
    action: QuickActionType;
    summary: string;
  } | null>(null);
  const consoleContainerRef = useRef<HTMLDivElement>(null);

  const metrics = calculateResourceMetrics(server);
  const chartData = buildTelemetryChartData(server);
  const isRunning = server.status === 'RUNNING';
  const isOffline = server.status === 'OFFLINE';

  useEffect(() => {
    if (mode === 'console' && consoleContainerRef.current) {
      consoleContainerRef.current.scrollTop = consoleContainerRef.current.scrollHeight;
    }
  }, [server.logs.length, mode]);

  const copyValue = (text: string, label: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedField(label);
    onShowToast(`Copied ${label}: ${text}`);
    setTimeout(() => setCopiedField(null), 1800);
  };

  const handleToggleLoadSpike = () => {
    if (!onUpdateServer) return;
    const nextSpikeState = !metrics.isHighLoadWarning;
    const updated = toggleSimulatedLoadSpike(server, nextSpikeState);
    onUpdateServer(updated);
    onShowToast(
      nextSpikeState
        ? `High resource load warning triggered on ${server.name} (>90% CPU & RAM)`
        : `Resource load normalized on ${server.name}`
    );
  };

  const handleQuickAction = (action: QuickActionType) => {
    if (runningQuickAction) return;
    setRunningQuickAction(action);
    const result = executeQuickAction(server, action);
    if (onUpdateServer) {
      onUpdateServer(result.updatedServer);
    }
    setQuickActionStatus({
      action,
      summary: result.actionSummary,
    });
    onShowToast(result.toastMessage);
    setTimeout(() => {
      setRunningQuickAction(null);
    }, 300);
  };

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim()) return;
    onSendCommand(commandInput);
    setCommandHistory((prev) => [commandInput.trim(), ...prev.slice(0, 19)]);
    setCommandInput('');
    setHistoryIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      const nextIdx = Math.min(historyIndex + 1, commandHistory.length - 1);
      if (nextIdx >= 0 && commandHistory[nextIdx]) {
        setHistoryIndex(nextIdx);
        setCommandInput(commandHistory[nextIdx]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      const nextIdx = historyIndex - 1;
      if (nextIdx >= 0 && commandHistory[nextIdx]) {
        setHistoryIndex(nextIdx);
        setCommandInput(commandHistory[nextIdx]);
      } else {
        setHistoryIndex(-1);
        setCommandInput('');
      }
    }
  };

  const buildSparklinePoints = (values: number[], maxVal: number, width = 260, height = 44) => {
    if (!values.length) return '';
    const safeMax = Math.max(maxVal, ...values, 1);
    return values
      .map((val, idx) => {
        const x = (idx / Math.max(1, values.length - 1)) * width;
        const y = height - Math.min(height - 4, (val / safeMax) * (height - 8)) - 2;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  };

  const getFlag = (code: string) => {
    if (code === 'IN') return '🇮🇳';
    if (code === 'SG') return '🇸🇬';
    if (code === 'DE') return '🇩🇪';
    return '🌐';
  };

  const renderHighLoadWarningBanner = () => {
    if (!metrics.isHighLoadWarning) return null;

    const exceededResources: string[] = [];
    if (metrics.isCpuCritical) {
      exceededResources.push(`CPU at ${server.cpuPercent.toFixed(1)}%`);
    }
    if (metrics.isMemoryCritical) {
      exceededResources.push(
        `RAM at ${metrics.memoryPercentage.toFixed(1)}% (${server.memoryUsedGB.toFixed(2)} GB / ${server.memoryLimitGB} GB)`
      );
    }

    return (
      <div
        role="alert"
        data-testid="resource-warning-banner"
        className="rounded-2xl px-5 py-3.5 bg-gradient-to-r from-red-950/95 via-red-900/80 to-amber-950/90 border border-red-500 shadow-[0_0_30px_rgba(167, 139, 250,0.5)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-pulse"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-red-500/25 border border-red-400/60 flex items-center justify-center text-red-300 shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-display font-bold text-white tracking-wide flex items-center gap-2">
              <span>CRITICAL RESOURCE THRESHOLD EXCEEDED (&gt;90%)</span>
            </div>
            <div className="text-xs text-red-100/90 font-mono mt-0.5 tabular-nums">
              {server.name} is operating above 90% capacity: {exceededResources.join(' · ')}
            </div>
          </div>
        </div>

        {onUpdateServer && (
          <button
            type="button"
            onClick={handleToggleLoadSpike}
            className="px-3.5 py-1.5 rounded-xl bg-black/70 hover:bg-black text-xs font-semibold text-red-200 border border-red-400/50 transition-colors shrink-0 whitespace-nowrap"
          >
            Normalize Load
          </button>
        )}
      </div>
    );
  };

  const renderSparklineCardsRow = () => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* CPU Card */}
      <div
        className={`bg-[#0c0818]/85 backdrop-blur-xl rounded-2xl p-4 flex flex-col justify-between relative overflow-hidden transition-all ${
          metrics.isCpuCritical
            ? 'border-2 border-red-500 shadow-[0_0_25px_rgba(167, 139, 250,0.45)] animate-pulse'
            : 'border border-red-950/60'
        }`}
      >
        <div>
          <div className="flex items-center justify-between gap-1.5 text-xs text-zinc-400">
            <span className="flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-red-400" />
              <span>CPU</span>
            </span>
            {metrics.isCpuCritical && (
              <span
                data-testid="cpu-warning-indicator"
                className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-red-300 bg-red-500/25 border border-red-400/50 px-2 py-0.5 rounded animate-pulse"
              >
                <AlertTriangle className="w-3 h-3 text-red-400" />
                <span>&gt;90% LIMIT</span>
              </span>
            )}
          </div>
          <div
            className={`text-xl font-mono font-bold mt-1.5 tabular-nums ${
              metrics.isCpuCritical ? 'text-red-400' : 'text-white'
            }`}
          >
            {isOffline ? '0.0%' : `${server.cpuPercent.toFixed(1)}%`}
          </div>
          <div className="text-[11px] text-zinc-500 mt-0.5 font-mono">
            of {server.cpuCores} cores
          </div>
        </div>
        <svg className="w-full h-7 mt-3 overflow-visible" viewBox="0 0 260 32">
          <polyline
            fill="none"
            stroke="#a78bfa"
            strokeWidth="2"
            points={buildSparklinePoints(server.cpuHistory, 100, 260, 30)}
          />
        </svg>
      </div>

      {/* Memory Card */}
      <div
        className={`bg-[#0c0818]/85 backdrop-blur-xl rounded-2xl p-4 flex flex-col justify-between relative overflow-hidden transition-all ${
          metrics.isMemoryCritical
            ? 'border-2 border-red-500 shadow-[0_0_25px_rgba(167, 139, 250,0.45)] animate-pulse'
            : 'border border-red-950/60'
        }`}
      >
        <div>
          <div className="flex items-center justify-between gap-1.5 text-xs text-zinc-400">
            <span className="flex items-center gap-1.5">
              <MemoryStick className="w-3.5 h-3.5 text-red-400" />
              <span>Memory</span>
            </span>
            {metrics.isMemoryCritical && (
              <span
                data-testid="ram-warning-indicator"
                className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-red-300 bg-red-500/25 border border-red-400/50 px-2 py-0.5 rounded animate-pulse"
              >
                <AlertTriangle className="w-3 h-3 text-red-400" />
                <span>{metrics.memoryPercentage}% RAM</span>
              </span>
            )}
          </div>
          <div
            className={`text-xl font-mono font-bold mt-1.5 tabular-nums ${
              metrics.isMemoryCritical ? 'text-red-400' : 'text-white'
            }`}
          >
            {isOffline ? '0.00 GB' : `${server.memoryUsedGB.toFixed(2)} GB`}
          </div>
          <div className="text-[11px] text-zinc-500 mt-0.5 font-mono">
            of {server.memoryLimitGB} GB ({metrics.memoryPercentage}%)
          </div>
        </div>
        <svg className="w-full h-7 mt-3 overflow-visible" viewBox="0 0 260 32">
          <polyline
            fill="none"
            stroke={metrics.isMemoryCritical ? '#a78bfa' : '#f59e0b'}
            strokeWidth="2"
            points={buildSparklinePoints(server.memoryHistory, server.memoryLimitGB, 260, 30)}
          />
        </svg>
      </div>

      {/* Disk Card */}
      <div className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-4 flex flex-col justify-between relative overflow-hidden">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-zinc-400">
            <HardDrive className="w-3.5 h-3.5 text-red-400" />
            <span>Disk</span>
          </div>
          <div className="text-xl font-mono font-bold text-white mt-1.5 tabular-nums">
            {server.diskUsedGB.toFixed(2)} GB
          </div>
          <div className="text-[11px] text-zinc-500 mt-0.5 font-mono">
            of {server.diskLimitGB} GB
          </div>
        </div>
        <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden mt-4">
          <div
            className="h-full bg-gradient-to-r from-red-600 to-red-400 rounded-full"
            style={{ width: `${Math.max(4, metrics.diskPercentage)}%` }}
          />
        </div>
      </div>

      {/* Network Card */}
      <div className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-4 flex flex-col justify-between relative overflow-hidden">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-zinc-400">
            <Network className="w-3.5 h-3.5 text-red-400" />
            <span>Network</span>
          </div>
          <div className="flex items-center gap-4 mt-1.5 font-mono tabular-nums">
            <span className="text-xl font-bold text-white">
              {isOffline ? '0 B/s' : `${server.netInBps} B/s`}
            </span>
            <span className="text-xl font-bold text-white">
              {isOffline ? '0 B/s' : `${server.netOutBps} B/s`}
            </span>
          </div>
          <div className="flex items-center gap-6 text-[11px] text-zinc-400 mt-0.5">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-0.5 bg-red-500 inline-block" /> In
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-0.5 bg-zinc-400 inline-block" /> Out
            </span>
          </div>
        </div>
        <svg className="w-full h-7 mt-3 overflow-visible" viewBox="0 0 260 32">
          <polyline
            fill="none"
            stroke="#a78bfa"
            strokeWidth="1.8"
            points={buildSparklinePoints(server.netHistory, 2000, 260, 30)}
          />
        </svg>
      </div>
    </div>
  );

  const renderRechartsTelemetryGraphs = () => {
    const peakCpu = server.cpuHistory.length ? Math.max(...server.cpuHistory) : 0;
    const peakNetOut = server.netHistory.length ? Math.max(...server.netHistory) : 0;

    return (
      <div
        data-testid="recharts-telemetry-section"
        className="grid grid-cols-1 lg:grid-cols-2 gap-4"
      >
        {/* Real-Time CPU Load History (Recharts AreaChart) */}
        <div
          data-testid="recharts-cpu-card"
          className={`bg-[#0c0818]/85 backdrop-blur-xl rounded-2xl p-5 flex flex-col justify-between transition-all ${
            metrics.isCpuCritical
              ? 'border-2 border-red-500 shadow-[0_0_25px_rgba(167, 139, 250,0.4)] animate-pulse'
              : 'border border-red-950/60'
          }`}
        >
          <div className="flex items-start justify-between gap-2 mb-3">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                <Activity className="w-3.5 h-3.5 text-red-400" />
                <span>Real-Time CPU History</span>
                {metrics.isCpuCritical && (
                  <span className="text-[10px] font-mono font-bold text-red-300 bg-red-500/25 border border-red-400/50 px-1.5 py-0.5 rounded">
                    SPIKE &gt;90%
                  </span>
                )}
              </div>
              <div className="flex items-baseline gap-2.5 mt-1">
                <span
                  className={`text-xl font-mono font-bold tabular-nums ${
                    metrics.isCpuCritical ? 'text-red-400' : 'text-white'
                  }`}
                >
                  {isOffline ? '0.0%' : `${server.cpuPercent.toFixed(1)}%`}
                </span>
                <span className="text-[11px] font-mono text-zinc-400 tabular-nums">
                  peak {peakCpu.toFixed(1)}% · {server.cpuCores} vCores
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 text-[11px] font-mono text-zinc-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-red-500/80 border border-red-400 inline-block" />
                <span>CPU %</span>
              </span>
              <span className="flex items-center gap-1.5 text-red-300/80">
                <span className="w-3 h-0.5 border-t border-dashed border-red-400 inline-block" />
                <span>90% Warn</span>
              </span>
            </div>
          </div>

          <div className="w-full h-44">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={chartData}
                margin={{ top: 6, right: 8, left: -18, bottom: 0 }}
              >
                <defs>
                  <linearGradient id={`cpuGrad-${server.id}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a78bfa" stopOpacity={0.55} />
                    <stop offset="95%" stopColor="#a78bfa" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="rgba(255,255,255,0.06)"
                  vertical={false}
                />
                <XAxis
                  dataKey="tick"
                  stroke="#71717a"
                  fontSize={10}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  domain={[0, 100]}
                  stroke="#71717a"
                  fontSize={10}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(val) => `${val}%`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0a0716',
                    borderColor: 'rgba(167, 139, 250,0.45)',
                    borderRadius: '12px',
                    fontSize: '11px',
                    fontFamily: 'JetBrains Mono, monospace',
                    color: '#f4f4f5',
                  }}
                  formatter={(value) => [`${Number(value ?? 0).toFixed(1)}%`, 'CPU Load']}
                />
                <ReferenceLine
                  y={90}
                  stroke="#a78bfa"
                  strokeDasharray="4 4"
                  strokeOpacity={0.75}
                />
                <Area
                  type="monotone"
                  dataKey="cpu"
                  stroke="#a78bfa"
                  strokeWidth={2.2}
                  fillOpacity={1}
                  fill={`url(#cpuGrad-${server.id})`}
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Real-Time Network Bandwidth History (Recharts AreaChart) */}
        <div
          data-testid="recharts-network-card"
          className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-5 flex flex-col justify-between"
        >
          <div className="flex items-start justify-between gap-2 mb-3">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                <Network className="w-3.5 h-3.5 text-red-400" />
                <span>Real-Time Network Bandwidth History</span>
              </div>
              <div className="flex flex-wrap items-baseline gap-3 mt-1 font-mono tabular-nums">
                <span className="text-xl font-bold text-white">
                  {isOffline ? '0 B/s' : `${server.netInBps} B/s`}{' '}
                  <span className="text-[11px] font-normal text-amber-300">IN</span>
                </span>
                <span className="text-xl font-bold text-white">
                  {isOffline ? '0 B/s' : `${server.netOutBps} B/s`}{' '}
                  <span className="text-[11px] font-normal text-red-400">OUT</span>
                </span>
                <span className="text-[11px] text-zinc-400">
                  peak {peakNetOut} B/s
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 text-[11px] font-mono text-zinc-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-red-500/80 border border-red-400 inline-block" />
                <span>Outbound</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-amber-500/80 border border-amber-400 inline-block" />
                <span>Inbound</span>
              </span>
            </div>
          </div>

          <div className="w-full h-44">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={chartData}
                margin={{ top: 10, right: 8, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id={`netOutGrad-${server.id}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a78bfa" stopOpacity={0.5} />
                    <stop offset="95%" stopColor="#a78bfa" stopOpacity={0.02} />
                  </linearGradient>
                  <linearGradient id={`netInGrad-${server.id}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="rgba(255,255,255,0.06)"
                  vertical={false}
                />
                <XAxis
                  dataKey="tick"
                  stroke="#71717a"
                  fontSize={10}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  width={54}
                  stroke="#71717a"
                  fontSize={10}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(val) => `${val} B/s`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0a0716',
                    borderColor: 'rgba(167, 139, 250,0.45)',
                    borderRadius: '12px',
                    fontSize: '11px',
                    fontFamily: 'JetBrains Mono, monospace',
                    color: '#f4f4f5',
                  }}
                  formatter={(value, name) => [
                    `${Number(value ?? 0)} B/s`,
                    name === 'netOutBps' ? 'Outbound Bandwidth' : 'Inbound Bandwidth',
                  ]}
                />
                <Area
                  type="monotone"
                  dataKey="netOutBps"
                  stroke="#a78bfa"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill={`url(#netOutGrad-${server.id})`}
                  isAnimationActive={false}
                />
                <Area
                  type="monotone"
                  dataKey="netInBps"
                  stroke="#f59e0b"
                  strokeWidth={1.8}
                  fillOpacity={1}
                  fill={`url(#netInGrad-${server.id})`}
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    );
  };

  const renderQuickActionsRow = () => (
    <div
      data-testid="quick-actions-row"
      className="bg-[#0a0716]/90 backdrop-blur-xl border border-red-950/70 rounded-2xl px-4 py-3 flex flex-col xl:flex-row xl:items-center justify-between gap-3 shadow-[0_6px_25px_rgba(0,0,0,0.45)]"
    >
      <div className="flex flex-wrap items-center gap-2.5 min-w-0">
        <div className="w-7 h-7 rounded-lg bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400 shrink-0">
          <Zap className="w-3.5 h-3.5" />
        </div>
        <span className="text-xs font-display font-bold text-white tracking-wide whitespace-nowrap">
          Quick Actions
        </span>
        <span className="text-[11px] font-mono text-zinc-400 hidden sm:inline whitespace-nowrap">
          · Instant one-click daemon tasks
        </span>
        {quickActionStatus && (
          <span
            data-testid="quick-action-status-badge"
            className="inline-flex items-center gap-1 text-[10px] font-mono font-semibold text-emerald-300 bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 rounded-md whitespace-nowrap"
          >
            <Check className="w-3 h-3 text-emerald-400 shrink-0" />
            <span>{quickActionStatus.summary}</span>
          </span>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-2 shrink-0">
        <button
          type="button"
          data-testid="quick-action-clear-cache"
          onClick={() => handleQuickAction('clear_cache')}
          disabled={runningQuickAction !== null}
          className="px-3 py-1.5 rounded-xl bg-red-950/35 hover:bg-red-600/25 border border-red-500/30 hover:border-red-400/60 text-xs font-semibold text-zinc-200 hover:text-white flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap"
        >
          {runningQuickAction === 'clear_cache' ? (
            <Loader2 className="w-3.5 h-3.5 text-red-400 animate-spin" />
          ) : (
            <Trash2 className="w-3.5 h-3.5 text-red-400" />
          )}
          <span>Clear Cache</span>
        </button>

        <button
          type="button"
          data-testid="quick-action-backup-now"
          onClick={() => handleQuickAction('backup_now')}
          disabled={runningQuickAction !== null}
          className="px-3 py-1.5 rounded-xl bg-red-950/35 hover:bg-red-600/25 border border-red-500/30 hover:border-red-400/60 text-xs font-semibold text-zinc-200 hover:text-white flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap"
        >
          {runningQuickAction === 'backup_now' ? (
            <Loader2 className="w-3.5 h-3.5 text-red-400 animate-spin" />
          ) : (
            <Archive className="w-3.5 h-3.5 text-red-400" />
          )}
          <span>Backup Now</span>
          <span
            data-testid="quick-action-backup-count"
            className="ml-0.5 px-1.5 py-0.2 rounded bg-black/60 border border-red-500/30 text-[10px] font-mono text-red-300 tabular-nums"
          >
            {server.backups.length}
          </span>
        </button>

        <button
          type="button"
          data-testid="quick-action-update-plugins"
          onClick={() => handleQuickAction('update_plugins')}
          disabled={runningQuickAction !== null}
          className="px-3 py-1.5 rounded-xl bg-red-950/35 hover:bg-red-600/25 border border-red-500/30 hover:border-red-400/60 text-xs font-semibold text-zinc-200 hover:text-white flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap"
        >
          {runningQuickAction === 'update_plugins' ? (
            <Loader2 className="w-3.5 h-3.5 text-red-400 animate-spin" />
          ) : (
            <RefreshCw className="w-3.5 h-3.5 text-red-400" />
          )}
          <span>Update Plugins</span>
        </button>

        <button
          type="button"
          data-testid="quick-action-save-world"
          onClick={() => handleQuickAction('save_world')}
          disabled={runningQuickAction !== null}
          className="px-3 py-1.5 rounded-xl bg-red-950/35 hover:bg-red-600/25 border border-red-500/30 hover:border-red-400/60 text-xs font-semibold text-zinc-200 hover:text-white flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap"
        >
          {runningQuickAction === 'save_world' ? (
            <Loader2 className="w-3.5 h-3.5 text-red-400 animate-spin" />
          ) : (
            <Save className="w-3.5 h-3.5 text-red-400" />
          )}
          <span>{server.category === 'minecraft' ? 'Flush & Save World' : 'Sync Shard State'}</span>
        </button>
      </div>
    </div>
  );

  // CONSOLE VIEW (Matches Reference Screenshot 3)
  if (mode === 'console') {
    const filteredLogs = logFilter.trim()
      ? server.logs.filter(
          (l) =>
            l.message.toLowerCase().includes(logFilter.toLowerCase()) ||
            l.source.toLowerCase().includes(logFilter.toLowerCase())
        )
      : server.logs;

    return (
      <div
        className="px-6 lg:px-10 py-4 space-y-4 max-w-[1440px]"
      >
        {renderHighLoadWarningBanner()}
        {renderQuickActionsRow()}
        {/* Terminal Console Output Box */}
        <div className="bg-[#050203]/95 border border-red-950/70 rounded-2xl overflow-hidden shadow-[0_12px_40px_rgba(0,0,0,0.75)]">
          {/* Subtle Top Terminal Bar with Server Status, Live Uptime & Quick Commands */}
          <div className="px-4 py-2.5 bg-[#09061a] border-b border-red-950/60 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <TerminalIcon className="w-4 h-4 text-red-400" />
              <span className="text-xs font-semibold text-zinc-200">
                {server.name} — Live Container Stream
              </span>
              <span className="text-[11px] font-mono text-zinc-400">
                · {server.status}
              </span>
              <span
                data-testid="console-uptime"
                className="text-[11px] font-mono text-red-300 tabular-nums"
              >
                · up {isOffline ? '0s' : server.uptime}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              {(server.category === 'minecraft'
                ? ['tps', 'list', 'plugins', 'version', 'save-all']
                : ['status', 'shards', 'guilds', 'lavalink']
              ).map((quickCmd) => (
                <button
                  key={quickCmd}
                  type="button"
                  onClick={() => onSendCommand(quickCmd)}
                  className="px-2.5 py-1 rounded-lg bg-red-950/40 hover:bg-red-600/30 border border-red-500/30 text-[11px] font-mono text-red-300 hover:text-white transition-colors"
                >
                  /{quickCmd}
                </button>
              ))}
            </div>
          </div>

          {/* Scrollable Log Output matching Screenshot 3 */}
          <div
            ref={consoleContainerRef}
            data-testid="console-output"
            className="h-[360px] overflow-y-auto p-4 font-mono text-xs leading-relaxed space-y-1 select-text"
          >
            {filteredLogs.map((log) => {
              const colorClass =
                log.level === 'WARN'
                  ? 'text-amber-400'
                  : log.level === 'ERROR'
                  ? 'text-red-500 font-semibold'
                  : log.level === 'CMD'
                  ? 'text-red-300 font-semibold'
                  : 'text-zinc-200';

              return (
                <div key={log.id} className={`${colorClass} break-words`}>
                  <span className="text-zinc-400">[{log.timestamp} </span>
                  <span>{log.level}]: </span>
                  <span className="text-zinc-300">[{log.source}] </span>
                  <span>{log.message}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Command Input Bar matching Screenshot 3 (`>> Type a command...`) */}
        <form
          onSubmit={handleCommandSubmit}
          className="bg-[#0a0716]/90 backdrop-blur-xl border border-red-950/70 focus-within:border-red-500/70 rounded-xl px-4 py-2.5 flex items-center justify-between gap-3 shadow-lg transition-colors"
        >
          <span className="text-xs font-mono text-red-400 select-none">»</span>
          <input
            type="text"
            value={commandInput}
            onChange={(e) => setCommandInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a command..."
            aria-label="Type a command..."
            className="flex-1 bg-transparent text-xs font-mono text-white placeholder:text-zinc-500 focus:outline-none"
          />

          {showLogSearch && (
            <input
              type="text"
              value={logFilter}
              onChange={(e) => setLogFilter(e.target.value)}
              placeholder="Filter logs..."
              aria-label="Filter console logs"
              className="w-40 bg-black/60 border border-red-900/50 rounded-lg px-2.5 py-1 text-xs font-mono text-zinc-200 focus:outline-none"
            />
          )}

          <div className="flex items-center gap-2 text-zinc-400">
            <button
              type="button"
              aria-label="Toggle log search"
              onClick={() => setShowLogSearch(!showLogSearch)}
              className="p-1.5 rounded-lg hover:bg-white/[0.06] hover:text-red-400 transition-colors"
            >
              <Search className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              aria-label="Load previous command"
              onClick={() => {
                if (commandHistory.length > 0) {
                  setCommandInput(commandHistory[0]);
                }
              }}
              className="p-1.5 rounded-lg hover:bg-white/[0.06] hover:text-red-400 transition-colors"
            >
              <History className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>

        {/* Prominent Copy Address Banner (Matches Screenshot 3 Banner in Crimson Red Gradient) */}
        <div
          onClick={() => copyValue(server.hostname, 'Server Address')}
          className="relative overflow-hidden rounded-2xl p-5 bg-gradient-to-r from-red-600 via-red-700 to-red-900 border border-red-400/50 shadow-[0_10px_35px_rgba(139, 92, 246,0.35)] cursor-pointer group"
        >
          {/* Decorative Dotted World Grid Pattern on Right matching Screenshot 3 */}
          <div
            aria-hidden="true"
            className="absolute right-4 top-2 bottom-2 w-48 opacity-25 pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(#ffffff 1.5px, transparent 1.5px)',
              backgroundSize: '8px 8px',
            }}
          />

          <div className="relative z-10 space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-medium text-red-100">
              <span>Copy address</span>
              {copiedField === 'Server Address' ? (
                <Check className="w-3.5 h-3.5 text-white" />
              ) : (
                <Copy className="w-3.5 h-3.5 text-red-100 group-hover:scale-110 transition-transform" />
              )}
            </div>
            <div className="text-lg sm:text-xl font-mono font-bold text-white tracking-tight">
              {server.hostname}
            </div>
            <div className="text-xs text-red-100/85">
              Point your client here to connect.
            </div>
          </div>
        </div>

        {/* Bottom 4 Live Sparkline Cards */}
        {renderSparklineCardsRow()}

        {/* Recharts Real-Time CPU & Network Bandwidth Graphs */}
        {renderRechartsTelemetryGraphs()}

        <footer className="pt-2 pb-6 text-[11px] text-zinc-400 space-y-0.5">
          <div>Pterodactyl® © 2015 - 2026</div>
          <div className="text-red-400/90 font-medium">
            Powered By BᴜʟᴋNᴏᴅᴇ | ꜰᴀsᴛ &amp; ʀᴇʟɪᴀʙʟᴇ ʜᴏsᴛɪɴɢ 🚀
          </div>
        </footer>
      </div>
    );
  }

  // OVERVIEW VIEW (Matches Reference Screenshot 2)
  const ipOnly = server.hostname.split(':')[0] || server.ip;

  return (
    <div
      className="px-6 lg:px-10 py-4 space-y-5 max-w-[1440px]"
    >
      {renderHighLoadWarningBanner()}

      {/* Top Server Header Card with Power Buttons (Matches Reference Screenshot 2) */}
      <div className="bg-[#0b0716]/90 backdrop-blur-2xl border border-red-950/70 rounded-2xl p-5 flex flex-col xl:flex-row xl:items-center justify-between gap-4 shadow-[0_10px_35px_rgba(0,0,0,0.55)]">
        <div className="flex items-center gap-4 min-w-0">
          <div className="w-12 h-12 rounded-2xl bg-black/90 border border-red-500/40 p-1 shrink-0 shadow-[0_0_20px_rgba(139, 92, 246,0.25)]">
            <img
              src="/assets/aistudio/image_a5091caf.png"
              alt={server.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain rounded-xl"
            />
          </div>

          <div className="min-w-0 space-y-1">
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="text-lg sm:text-xl font-display font-bold text-white truncate">
                {server.name}
              </h1>
              <span
                className={`text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-md ${
                  isRunning
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : isOffline
                    ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                }`}
              >
                {server.status}
              </span>
              {metrics.isHighLoadWarning && (
                <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-md bg-red-500/30 text-red-200 border border-red-400 animate-pulse">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                  <span>HIGH LOAD (&gt;90%)</span>
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-400">
              <span>{getFlag(server.countryCode)}</span>
              <span>{server.node}</span>
              <span>·</span>
              <span>up {server.uptime}</span>

              <button
                type="button"
                onClick={() => copyValue(ipOnly, 'IP')}
                className="ml-1 px-2 py-0.5 rounded bg-white/[0.05] hover:bg-red-600/20 border border-white/10 text-[11px] font-mono text-zinc-300 flex items-center gap-1.5 transition-colors"
              >
                <span className="text-zinc-500">IP</span>
                <span>{ipOnly}</span>
              </button>

              <button
                type="button"
                onClick={() => copyValue(String(server.port), 'PORT')}
                className="px-2 py-0.5 rounded bg-white/[0.05] hover:bg-red-600/20 border border-white/10 text-[11px] font-mono text-zinc-300 flex items-center gap-1.5 transition-colors"
              >
                <span className="text-zinc-500">PORT</span>
                <span>{server.port}</span>
              </button>

              <button
                type="button"
                aria-label="Copy full server address"
                onClick={() => copyValue(server.hostname, 'Hostname')}
                className="p-1 text-zinc-400 hover:text-red-400 transition-colors"
              >
                {copiedField === 'Hostname' ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right Segmented Power Controls (`Start`, `Restart`, `Stop`, `Kill`) + Load Spike Simulator */}
        <div className="flex flex-wrap items-center gap-2 self-start xl:self-center shrink-0">
          {onUpdateServer && (
            <button
              type="button"
              onClick={handleToggleLoadSpike}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all whitespace-nowrap ${
                metrics.isHighLoadWarning
                  ? 'bg-red-600/30 border-red-400 text-red-200 animate-pulse'
                  : 'bg-black/60 border-red-950/70 text-zinc-300 hover:border-red-500/50 hover:text-red-300'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-red-400" />
              <span>
                {metrics.isHighLoadWarning ? 'Normalize Load' : 'Simulate >90% Load'}
              </span>
            </button>
          )}

          <div className="flex items-center bg-black/60 border border-red-950/70 rounded-xl p-1">
            <button
              type="button"
              disabled={isRunning || powerLoading !== null}
              onClick={() => onPowerAction('start')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                isRunning
                  ? 'text-emerald-500/40 cursor-not-allowed'
                  : 'text-emerald-400 hover:bg-emerald-500/15'
              }`}
            >
              {powerLoading === 'start' ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Play className="w-3.5 h-3.5" />
              )}
              <span>Start</span>
            </button>

            <div className="w-px h-4 bg-red-950/60" />

            <button
              type="button"
              disabled={powerLoading !== null}
              onClick={() => onPowerAction('restart')}
              className="px-3.5 py-1.5 rounded-lg text-xs font-semibold text-amber-400 hover:bg-amber-500/15 flex items-center gap-1.5 transition-all whitespace-nowrap"
            >
              {powerLoading === 'restart' ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <RotateCw className="w-3.5 h-3.5" />
              )}
              <span>Restart</span>
            </button>

            <div className="w-px h-4 bg-red-950/60" />

            <button
              type="button"
              disabled={isOffline || powerLoading !== null}
              onClick={() => onPowerAction('stop')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                isOffline
                  ? 'text-red-500/40 cursor-not-allowed'
                  : 'text-red-400 hover:bg-red-500/20'
              }`}
            >
              {powerLoading === 'stop' ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Square className="w-3.5 h-3.5" />
              )}
              <span>Stop</span>
            </button>

            <div className="w-px h-4 bg-red-950/60" />

            <button
              type="button"
              disabled={isOffline || powerLoading !== null}
              onClick={() => onPowerAction('kill')}
              className="px-3.5 py-1.5 rounded-lg text-xs font-semibold text-zinc-300 hover:text-red-400 hover:bg-red-500/15 flex items-center gap-1.5 transition-all whitespace-nowrap"
            >
              <Power className="w-3.5 h-3.5" />
              <span>Kill</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Actions Secondary Row */}
      {renderQuickActionsRow()}

      {/* Row 1: 4 Mini Sparkline Cards */}
      {renderSparklineCardsRow()}

      {/* Row 1.5: Interactive Recharts Real-Time CPU & Network Bandwidth Graphs */}
      {renderRechartsTelemetryGraphs()}

      {/* Row 2: 3 Detailed Telemetry Charts (CPU Chart, Memory Chart, Disk Usage Donut Gauge) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Detailed CPU Chart */}
        <div
          className={`bg-[#0c0818]/85 backdrop-blur-xl rounded-2xl p-5 flex flex-col justify-between min-h-[230px] transition-all ${
            metrics.isCpuCritical
              ? 'border-2 border-red-500 shadow-[0_0_25px_rgba(167, 139, 250,0.4)] animate-pulse'
              : 'border border-red-950/60'
          }`}
        >
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                <Cpu className="w-3.5 h-3.5 text-red-400" />
                <span>CPU</span>
                {metrics.isCpuCritical && (
                  <span className="text-[10px] font-mono font-bold text-red-300 bg-red-500/25 px-1.5 py-0.5 rounded">
                    CRITICAL &gt;90%
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <span className="w-2 h-0.5 bg-red-500 inline-block" />
                <span
                  className={`text-xl font-mono font-bold tabular-nums ${
                    metrics.isCpuCritical ? 'text-red-400' : 'text-white'
                  }`}
                >
                  {isOffline ? '0.0%' : `${server.cpuPercent.toFixed(1)}%`}
                </span>
              </div>
            </div>
            <div className="text-right font-mono text-[11px] text-zinc-400 tabular-nums">
              <div>{metrics.cpuMaxScale.toFixed(1)}%</div>
              <div className="text-zinc-500">of {server.cpuCores} cores</div>
            </div>
          </div>

          <div className="my-3 space-y-2 text-[10px] font-mono text-zinc-500 tabular-nums">
            <div className="border-b border-white/[0.04] pb-1">
              {(metrics.cpuMaxScale * 0.75).toFixed(1)}%
            </div>
            <div className="border-b border-white/[0.04] pb-1">
              {(metrics.cpuMaxScale * 0.5).toFixed(1)}%
            </div>
            <div className="border-b border-white/[0.04] pb-1">
              {(metrics.cpuMaxScale * 0.25).toFixed(1)}%
            </div>
            <div className="relative pt-1">
              <span>0.0%</span>
              <svg className="w-full h-10 -mt-6 overflow-visible" viewBox="0 0 280 40">
                <polyline
                  fill="none"
                  stroke="#a78bfa"
                  strokeWidth="2.2"
                  points={buildSparklinePoints(server.cpuHistory, 50, 280, 36)}
                />
              </svg>
            </div>
          </div>

          <div className="text-[11px] text-zinc-500 font-mono">
            Last {server.cpuHistory.length} readings · peak{' '}
            {Math.max(...server.cpuHistory).toFixed(1)}%
          </div>
        </div>

        {/* Detailed Memory Chart */}
        <div
          className={`bg-[#0c0818]/85 backdrop-blur-xl rounded-2xl p-5 flex flex-col justify-between min-h-[230px] transition-all ${
            metrics.isMemoryCritical
              ? 'border-2 border-red-500 shadow-[0_0_25px_rgba(167, 139, 250,0.4)] animate-pulse'
              : 'border border-red-950/60'
          }`}
        >
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                <MemoryStick className="w-3.5 h-3.5 text-red-400" />
                <span>Memory</span>
                {metrics.isMemoryCritical && (
                  <span className="text-[10px] font-mono font-bold text-red-300 bg-red-500/25 px-1.5 py-0.5 rounded">
                    CRITICAL {metrics.memoryPercentage}%
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <span className="w-2 h-0.5 bg-amber-400 inline-block" />
                <span
                  className={`text-xl font-mono font-bold tabular-nums ${
                    metrics.isMemoryCritical ? 'text-red-400' : 'text-white'
                  }`}
                >
                  {isOffline ? '0.00 GB' : `${server.memoryUsedGB.toFixed(2)} GB`}
                </span>
              </div>
            </div>
            <div className="text-right font-mono text-[11px] text-zinc-400 tabular-nums">
              <div>{server.memoryLimitGB.toFixed(2)} GB</div>
              <div className="text-zinc-500">of {server.memoryLimitGB} GB</div>
            </div>
          </div>

          <div className="my-3 space-y-2 text-[10px] font-mono text-zinc-500 tabular-nums">
            <div className="border-b border-white/[0.04] pb-1">
              {(server.memoryLimitGB * 0.75).toFixed(2)} GB
            </div>
            <div className="border-b border-white/[0.04] pb-1">
              {(server.memoryLimitGB * 0.5).toFixed(2)} GB
            </div>
            <div className="border-b border-white/[0.04] pb-1">
              {(server.memoryLimitGB * 0.25).toFixed(2)} GB
            </div>
            <div className="relative pt-1">
              <span>0 MB</span>
              <svg className="w-full h-10 -mt-6 overflow-visible" viewBox="0 0 280 40">
                <polyline
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="2.2"
                  points={buildSparklinePoints(
                    server.memoryHistory,
                    server.memoryLimitGB,
                    280,
                    36
                  )}
                />
              </svg>
            </div>
          </div>

          <div className="text-[11px] text-zinc-500 font-mono">
            Last {server.memoryHistory.length} readings · peak{' '}
            {Math.max(...server.memoryHistory).toFixed(2)} GB
          </div>
        </div>

        {/* Disk Usage Radial Donut Chart Card (Matches Screenshot 2) */}
        <div className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-5 flex flex-col justify-between min-h-[230px]">
          <div className="flex items-center gap-1.5 text-xs text-zinc-400">
            <HardDrive className="w-3.5 h-3.5 text-red-400" />
            <span>Disk usage</span>
          </div>

          <div className="flex items-center justify-between gap-4 my-auto py-3">
            {/* SVG Circular Gauge */}
            <div className="relative w-28 h-28 flex items-center justify-center shrink-0">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="transparent"
                  stroke="rgba(255,255,255,0.07)"
                  strokeWidth="8"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="transparent"
                  stroke="#dc2626"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${Math.max(5, metrics.diskPercentage) * 2.51} 251.2`}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="text-lg font-mono font-bold text-white tabular-nums">
                  {metrics.diskPercentage}%
                </span>
                <span className="text-[10px] text-zinc-400">Used</span>
              </div>
            </div>

            {/* Used / Free / Limit Breakdown */}
            <div className="flex-1 space-y-2.5 text-xs font-mono tabular-nums">
              <div className="flex items-center justify-between">
                <span className="text-zinc-400 font-sans">Used</span>
                <span className="text-white font-semibold">
                  {server.diskUsedGB.toFixed(2)} GB
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-400 font-sans">Free</span>
                <span className="text-white font-semibold">
                  {metrics.diskFreeGB.toFixed(2)} GB
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-400 font-sans">Limit</span>
                <span className="text-white font-semibold">
                  {server.diskLimitGB.toFixed(1)} GB
                </span>
              </div>
            </div>
          </div>

          <div className="text-[11px] text-zinc-500">
            RAID-10 Gen5 NVMe Storage Pool
          </div>
        </div>
      </div>

      {/* Row 3: Server Info Card + Billing Card (Matches Reference Screenshot 2) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Server Info Table Card */}
        <div className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-sm font-display font-bold text-white">
            <Server className="w-4 h-4 text-red-400" />
            <span>Server Info</span>
          </div>

          <div className="divide-y divide-white/[0.05] text-xs">
            <div className="py-2.5 flex items-center justify-between">
              <span className="text-zinc-400">Status</span>
              <span
                className={`font-mono font-bold px-2.5 py-0.5 rounded ${
                  isRunning
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : isOffline
                    ? 'bg-red-500/20 text-red-400'
                    : 'bg-amber-500/20 text-amber-300'
                }`}
              >
                {server.status}
              </span>
            </div>

            <div className="py-2.5 flex items-center justify-between">
              <span className="text-zinc-400">Uptime</span>
              <span className="font-mono text-white font-semibold tabular-nums">
                {isOffline ? '0m' : server.uptime}
              </span>
            </div>

            <div className="py-2.5 flex items-center justify-between">
              <span className="text-zinc-400">Hostname</span>
              <button
                type="button"
                onClick={() => copyValue(server.hostname, 'Hostname')}
                className="px-2.5 py-1 rounded-lg bg-white/[0.04] hover:bg-red-600/20 border border-white/10 font-mono text-zinc-200 flex items-center gap-2 transition-colors"
              >
                <span>{server.hostname}</span>
                <Copy className="w-3.5 h-3.5 text-zinc-400" />
              </button>
            </div>

            <div className="py-2.5 flex items-center justify-between">
              <span className="text-zinc-400">Node</span>
              <span className="font-medium text-white flex items-center gap-1.5">
                <span>{getFlag(server.countryCode)}</span>
                <span>{server.node}</span>
              </span>
            </div>

            <div className="py-2.5 flex items-center justify-between">
              <span className="text-zinc-400">Server ID</span>
              <button
                type="button"
                onClick={() => copyValue(server.shortId, 'Server ID')}
                className="px-2.5 py-1 rounded-lg bg-white/[0.04] hover:bg-red-600/20 border border-white/10 font-mono text-zinc-200 flex items-center gap-2 transition-colors"
              >
                <span>{server.shortId}</span>
                <Copy className="w-3.5 h-3.5 text-zinc-400" />
              </button>
            </div>
          </div>
        </div>

        {/* Billing Card */}
        <div className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-display font-bold text-white">
              <CreditCard className="w-4 h-4 text-red-400" />
              <span>Billing</span>
            </div>
            <p className="text-xs text-zinc-400">
              {server.id === 'srv-hunter-stock'
                ? 'This server is not linked to a billing service (Custom Root Stock Plan).'
                : `Active Plan: ${server.billingPlan}`}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-br from-red-950/35 to-black/60 border border-red-500/25 space-y-2">
            <div className="text-xs font-semibold text-red-300">
              BᴜʟᴋNᴏᴅᴇ | ꜰᴀsᴛ &amp; ʀᴇʟɪᴀʙʟᴇ ʜᴏsᴛɪɴɢ 🚀 Hardware Guarantee
            </div>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Protected by 17.2 Tbps CosmicGuard + Path.net Game DDoS Mitigation. Automated daily off-site backups active.
            </p>
          </div>
        </div>
      </div>

      <footer className="pt-2 pb-6 text-[11px] text-zinc-400 space-y-0.5">
        <div>Pterodactyl® © 2015 - 2026</div>
        <div className="text-red-400/90 font-medium">
          Powered By BᴜʟᴋNᴏᴅᴇ | ꜰᴀsᴛ &amp; ʀᴇʟɪᴀʙʟᴇ ʜᴏsᴛɪɴɢ 🚀
        </div>
      </footer>
    </div>
  );
};
