import React, { useState } from 'react';
import {
  Search,
  LifeBuoy,
  ChevronDown,
  LogOut,
  Plus,
  Server,
  MessageSquare,
  Activity,
  BookOpen,
} from 'lucide-react';
import { ServerInstance } from '../utils/panelLogic';

interface TopBarProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  servers: ServerInstance[];
  onSelectServer: (serverId: string) => void;
  onOpenDeployModal: () => void;
  onOpenExternalModal: (modal: 'discord' | 'billing' | 'website' | 'support') => void;
  onShowToast: (msg: string) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  searchQuery,
  onSearchChange,
  servers,
  onSelectServer,
  onOpenDeployModal,
  onOpenExternalModal,
  onShowToast,
}) => {
  const [supportMenuOpen, setSupportMenuOpen] = useState(false);
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [selectedLang, setSelectedLang] = useState<'EN' | 'HI' | 'DE'>('EN');
  const [searchFocused, setSearchFocused] = useState(false);

  const matchingServers = searchQuery.trim()
    ? servers.filter(
        (s) =>
          s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.hostname.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.node.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <header className="w-full pt-5 pb-3 px-6 lg:px-10 flex items-center justify-between gap-4 z-20 relative">
      {/* Search Servers Bar */}
      <div className="relative flex-1 max-w-2xl">
        <Search className="w-4 h-4 text-zinc-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onFocus={() => setSearchFocused(true)}
          onBlur={() => setTimeout(() => setSearchFocused(false), 180)}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search servers"
          aria-label="Search servers"
          className="w-full bg-[#0b0817]/85 hover:bg-[#13080b]/90 focus:bg-[#14070a]/95 backdrop-blur-xl border border-red-950/60 focus:border-red-500/70 rounded-full pl-11 pr-4 py-2.5 text-sm text-zinc-100 placeholder:text-zinc-400 focus:outline-none shadow-[0_4px_24px_rgba(0,0,0,0.45)] transition-all"
        />

        {/* Quick Search Results Dropdown */}
        {searchFocused && searchQuery.trim().length > 0 && (
          <div className="absolute left-0 right-0 mt-2 bg-[#0f0a1f]/95 backdrop-blur-2xl border border-red-500/40 rounded-2xl shadow-2xl overflow-hidden z-50">
            {matchingServers.length === 0 ? (
              <div className="px-4 py-3 text-xs text-zinc-400">
                No instances matching "{searchQuery}"
              </div>
            ) : (
              matchingServers.map((srv) => (
                <button
                  key={srv.id}
                  type="button"
                  onClick={() => {
                    onSelectServer(srv.id);
                    onSearchChange('');
                  }}
                  className="w-full px-4 py-2.5 flex items-center justify-between hover:bg-red-600/20 transition-colors text-left border-b border-red-950/40 last:border-b-0"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Server className="w-4 h-4 text-red-400 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white truncate">
                        {srv.name}
                      </div>
                      <div className="text-[11px] text-zinc-400 font-mono truncate">
                        {srv.hostname} · {srv.node}
                      </div>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono text-red-400 shrink-0">
                    Manage →
                  </span>
                </button>
              ))
            )}
          </div>
        )}
      </div>

      {/* Right Action Pills (Matches Reference Top-Right Controls) */}
      <div className="flex items-center gap-2.5 shrink-0">
        <button
          type="button"
          onClick={onOpenDeployModal}
          className="px-4 py-2 rounded-full bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-[0_0_20px_rgba(139, 92, 246,0.4)] transition-all cursor-pointer whitespace-nowrap"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Deploy Server</span>
        </button>

        {/* Support Dropdown */}
        <div className="relative">
          <button
            type="button"
            onClick={() => {
              setSupportMenuOpen(!supportMenuOpen);
              setLangMenuOpen(false);
            }}
            className="px-4 py-2 rounded-full bg-[#0b0817]/85 hover:bg-[#140c26]/90 backdrop-blur-xl border border-red-950/60 hover:border-red-500/40 text-xs font-medium text-zinc-200 flex items-center gap-2 transition-all whitespace-nowrap"
          >
            <LifeBuoy className="w-3.5 h-3.5 text-red-400" />
            <span>Support</span>
            <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
          </button>

          {supportMenuOpen && (
            <div className="absolute right-0 mt-2 w-52 bg-[#0f0a1f]/95 backdrop-blur-2xl border border-red-500/40 rounded-2xl shadow-2xl py-1.5 z-50">
              <button
                type="button"
                onClick={() => {
                  setSupportMenuOpen(false);
                  onOpenExternalModal('support');
                }}
                className="w-full px-4 py-2 text-xs text-zinc-200 hover:bg-red-600/20 hover:text-red-300 flex items-center gap-2.5 text-left transition-colors"
              >
                <LifeBuoy className="w-3.5 h-3.5 text-red-400" />
                <span>Open Support Ticket</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setSupportMenuOpen(false);
                  onOpenExternalModal('discord');
                }}
                className="w-full px-4 py-2 text-xs text-zinc-200 hover:bg-red-600/20 hover:text-red-300 flex items-center gap-2.5 text-left transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5 text-red-400" />
                <span>Join BulkNode Discord</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setSupportMenuOpen(false);
                  onShowToast('All 28 BulkNode Global Nodes are 100% Online (0% Packet Loss)');
                }}
                className="w-full px-4 py-2 text-xs text-zinc-200 hover:bg-red-600/20 hover:text-red-300 flex items-center gap-2.5 text-left transition-colors"
              >
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                <span>Node Uptime Status</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setSupportMenuOpen(false);
                  onOpenExternalModal('website');
                }}
                className="w-full px-4 py-2 text-xs text-zinc-200 hover:bg-red-600/20 hover:text-red-300 flex items-center gap-2.5 text-left transition-colors"
              >
                <BookOpen className="w-3.5 h-3.5 text-red-400" />
                <span>Hosting Documentation</span>
              </button>
            </div>
          )}
        </div>

        {/* Language Selector */}
        <div className="relative">
          <button
            type="button"
            onClick={() => {
              setLangMenuOpen(!langMenuOpen);
              setSupportMenuOpen(false);
            }}
            className="px-3.5 py-2 rounded-full bg-[#0b0817]/85 hover:bg-[#140c26]/90 backdrop-blur-xl border border-red-950/60 hover:border-red-500/40 text-xs font-medium text-zinc-200 flex items-center gap-2 transition-all whitespace-nowrap"
          >
            <span className="text-xs">
              {selectedLang === 'EN' ? '🇬🇧' : selectedLang === 'HI' ? '🇮🇳' : '🇩🇪'}
            </span>
            <span>{selectedLang}</span>
            <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
          </button>

          {langMenuOpen && (
            <div className="absolute right-0 mt-2 w-36 bg-[#0f0a1f]/95 backdrop-blur-2xl border border-red-500/40 rounded-xl shadow-2xl py-1 z-50">
              {(['EN', 'HI', 'DE'] as const).map((lang) => (
                <button
                  key={lang}
                  type="button"
                  onClick={() => {
                    setSelectedLang(lang);
                    setLangMenuOpen(false);
                    onShowToast(`Panel locale switched to ${lang}`);
                  }}
                  className="w-full px-3.5 py-1.5 text-xs text-zinc-200 hover:bg-red-600/20 flex items-center justify-between text-left"
                >
                  <span>
                    {lang === 'EN' ? '🇬🇧 English' : lang === 'HI' ? '🇮🇳 हिन्दी (IN)' : '🇩🇪 Deutsch'}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Red Logout / Session Lock Button matching reference screenshot */}
        <button
          type="button"
          aria-label="Lock or Sign Out"
          onClick={() =>
            onShowToast('Session secured with BulkNode Hardware 2FA Guard.')
          }
          className="w-9 h-9 rounded-full bg-red-950/60 hover:bg-red-600/40 border border-red-500/40 flex items-center justify-center text-red-400 hover:text-white transition-all shadow-[0_0_15px_rgba(139, 92, 246,0.25)]"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
