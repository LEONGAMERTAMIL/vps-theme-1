import React, { useState } from 'react';
import {
  ChevronRight,
  SlidersHorizontal,
  FolderPlus,
  Copy,
  Check,
  Key,
  Terminal,
  ShieldCheck,
  Plus,
  Trash2,
  CreditCard,
  Activity,
  Gamepad2,
  Bot,
  Sparkles,
} from 'lucide-react';
import {
  ServerInstance,
  ServerCategory,
  filterServers,
} from '../utils/panelLogic';
import { AccountTab } from './Sidebar';

interface DashboardViewProps {
  servers: ServerInstance[];
  searchQuery: string;
  accountTab: AccountTab;
  onSelectServer: (serverId: string) => void;
  onSelectAccountTab: (tab: AccountTab) => void;
  onOpenDeployModal: () => void;
  onOpenExternalModal: (modal: 'discord' | 'billing' | 'website' | 'support') => void;
  onShowToast: (msg: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  servers,
  searchQuery,
  accountTab,
  onSelectServer,
  onSelectAccountTab,
  onOpenDeployModal,
  onOpenExternalModal,
  onShowToast,
}) => {
  const [categoryFilter, setCategoryFilter] = useState<'all' | ServerCategory>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Account API Keys & SSH Keys interactive state
  const [apiKeys, setApiKeys] = useState([
    {
      id: 'key-1',
      description: 'BulkNode WHMCS Billing Sync',
      identifier: 'ptlc_BN98x2mK7vQp4L1z',
      lastUsed: '4 minutes ago',
      created: '2026-10-14',
    },
    {
      id: 'key-2',
      description: 'Discord Bot Auto-Deploy CI/CD',
      identifier: 'ptlc_BN31f9wR5tYu8M2c',
      lastUsed: '2 hours ago',
      created: '2026-11-01',
    },
  ]);
  const [newKeyDesc, setNewKeyDesc] = useState('');

  const [sshKeys, setSshKeys] = useState([
    {
      id: 'ssh-1',
      name: 'Hunter-Workstation-Ed25519',
      fingerprint: 'SHA256:9xK4mP2vL8nQ1wR5tYu8M2cVbN7zX3aC',
      addedOn: '2026-09-20',
    },
  ]);
  const [newSshName, setNewSshName] = useState('');
  const [newSshPublicKey, setNewSshPublicKey] = useState('');

  const filteredServers = filterServers(servers, searchQuery, categoryFilter);

  const handleCopy = (text: string, id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    onShowToast(`Copied ${text} to clipboard`);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const getFlag = (code: string) => {
    if (code === 'IN') return '🇮🇳';
    if (code === 'SG') return '🇸🇬';
    if (code === 'DE') return '🇩🇪';
    return '🌐';
  };

  // Render Account Sub-Tabs if selected in Sidebar
  if (accountTab === 'account-overview') {
    return (
      <div
        className="px-6 lg:px-10 py-6 max-w-6xl space-y-6"
      >
        <div>
          <h1 className="text-2xl font-display font-bold text-white">Account Overview</h1>
          <p className="text-sm text-zinc-400 mt-1">
            Manage your BᴜʟᴋNᴏᴅᴇ root profile, security credentials, and 2FA settings.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-display font-semibold text-white">
              Account Identity
            </h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between py-2 border-b border-red-950/40">
                <span className="text-zinc-400">Username</span>
                <span className="font-mono text-white font-medium">hunterk.v</span>
              </div>
              <div className="flex justify-between py-2 border-b border-red-950/40">
                <span className="text-zinc-400">Email Address</span>
                <span className="font-mono text-white">contactallsaved@gmail.com</span>
              </div>
              <div className="flex justify-between py-2 border-b border-red-950/40">
                <span className="text-zinc-400">Account Tier</span>
                <span className="text-red-400 font-semibold">Enterprise Root Partner</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-zinc-400">2FA Hardware Guard</span>
                <span className="text-emerald-400 font-medium flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" /> Enabled (TOTP + Passkey)
                </span>
              </div>
            </div>
          </div>

          <div className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-display font-semibold text-white">
              Update Password
            </h2>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                onShowToast('Account password updated and active tokens refreshed.');
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs text-zinc-400 mb-1">Current Password</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••••••"
                  className="w-full bg-black/60 border border-red-950/70 focus:border-red-500 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-400 mb-1">New Password</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••••••"
                  className="w-full bg-black/60 border border-red-950/70 focus:border-red-500 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 text-xs font-semibold text-white shadow-[0_0_15px_rgba(139, 92, 246,0.3)] transition-all"
              >
                Save Security Credentials
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  if (accountTab === 'api-credentials') {
    return (
      <div
        className="px-6 lg:px-10 py-6 max-w-6xl space-y-6"
      >
        <div>
          <h1 className="text-2xl font-display font-bold text-white">Client API Credentials</h1>
          <p className="text-sm text-zinc-400 mt-1">
            Generate Pterodactyl Client API keys (`ptlc_*`) for automated Minecraft &amp; Discord bot deployments.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!newKeyDesc.trim()) return;
              const randomToken = `ptlc_BN${Math.random().toString(36).slice(2, 12).toUpperCase()}`;
              setApiKeys([
                {
                  id: `key-${Date.now()}`,
                  description: newKeyDesc.trim(),
                  identifier: randomToken,
                  lastUsed: 'Just now',
                  created: '2026-11-12',
                },
                ...apiKeys,
              ]);
              setNewKeyDesc('');
              onShowToast(`Generated new Client API Key: ${randomToken}`);
            }}
            className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-6 space-y-4 h-fit"
          >
            <h2 className="text-base font-display font-semibold text-white flex items-center gap-2">
              <Key className="w-4 h-4 text-red-400" /> Create API Key
            </h2>
            <div>
              <label className="block text-xs text-zinc-400 mb-1">Key Description</label>
              <input
                type="text"
                value={newKeyDesc}
                onChange={(e) => setNewKeyDesc(e.target.value)}
                placeholder="e.g. GitHub Actions Bot Deploy"
                required
                className="w-full bg-black/60 border border-red-950/70 focus:border-red-500 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 text-xs font-semibold text-white shadow-[0_0_15px_rgba(139, 92, 246,0.3)] transition-all"
            >
              Generate API Token
            </button>
          </form>

          <div className="lg:col-span-2 bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-6 space-y-3">
            <h2 className="text-base font-display font-semibold text-white">Active API Keys</h2>
            {apiKeys.map((k) => (
              <div
                key={k.id}
                className="flex items-center justify-between p-3.5 rounded-xl bg-black/50 border border-red-950/40"
              >
                <div>
                  <div className="text-sm font-semibold text-white">{k.description}</div>
                  <div className="text-xs font-mono text-red-400 mt-0.5">
                    {k.identifier} · Last used {k.lastUsed}
                  </div>
                </div>
                <button
                  type="button"
                  aria-label={`Delete API key ${k.description}`}
                  onClick={() => {
                    setApiKeys(apiKeys.filter((item) => item.id !== k.id));
                    onShowToast(`Revoked API key ${k.identifier}`);
                  }}
                  className="p-2 rounded-lg text-zinc-400 hover:text-red-400 hover:bg-red-950/40 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (accountTab === 'ssh-keys') {
    return (
      <div
        className="px-6 lg:px-10 py-6 max-w-6xl space-y-6"
      >
        <div>
          <h1 className="text-2xl font-display font-bold text-white">SSH Public Keys</h1>
          <p className="text-sm text-zinc-400 mt-1">
            Add Ed25519 or RSA SSH keys for passwordless SFTP access across all BᴜʟᴋNᴏᴅᴇ Wings nodes.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!newSshName.trim() || !newSshPublicKey.trim()) return;
              setSshKeys([
                ...sshKeys,
                {
                  id: `ssh-${Date.now()}`,
                  name: newSshName.trim(),
                  fingerprint: 'SHA256:7bN9xL4pQ2mV8wK1zR5tYu8M2cVbN7zX',
                  addedOn: '2026-11-12',
                },
              ]);
              setNewSshName('');
              setNewSshPublicKey('');
              onShowToast('SSH Public Key registered with BulkNode SFTP Daemon.');
            }}
            className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-base font-display font-semibold text-white">Add SSH Key</h2>
            <div>
              <label className="block text-xs text-zinc-400 mb-1">Key Name</label>
              <input
                type="text"
                value={newSshName}
                onChange={(e) => setNewSshName(e.target.value)}
                placeholder="e.g. MacBook Pro M4 Max"
                required
                className="w-full bg-black/60 border border-red-950/70 focus:border-red-500 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs text-zinc-400 mb-1">Public Key (`ssh-ed25519 ...`)</label>
              <textarea
                rows={3}
                value={newSshPublicKey}
                onChange={(e) => setNewSshPublicKey(e.target.value)}
                placeholder="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAI..."
                required
                className="w-full bg-black/60 border border-red-950/70 focus:border-red-500 rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-none"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 text-xs font-semibold text-white"
            >
              Save SSH Key
            </button>
          </form>

          <div className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl p-6 space-y-3">
            <h2 className="text-base font-display font-semibold text-white">Authorized Keys</h2>
            {sshKeys.map((k) => (
              <div
                key={k.id}
                className="flex items-center justify-between p-3.5 rounded-xl bg-black/50 border border-red-950/40"
              >
                <div>
                  <div className="text-sm font-semibold text-white">{k.name}</div>
                  <div className="text-xs font-mono text-zinc-400 mt-0.5">{k.fingerprint}</div>
                </div>
                <button
                  type="button"
                  onClick={() => setSshKeys(sshKeys.filter((item) => item.id !== k.id))}
                  className="p-2 rounded-lg text-zinc-400 hover:text-red-400"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (accountTab === 'account-activity' || accountTab === 'billing') {
    return (
      <div
        className="px-6 lg:px-10 py-6 max-w-6xl space-y-6"
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-display font-bold text-white">
              {accountTab === 'billing' ? 'Billing & Hosting Plans' : 'Account Audit Activity'}
            </h1>
            <p className="text-sm text-zinc-400 mt-1">
              {accountTab === 'billing'
                ? 'BᴜʟᴋNᴏᴅᴇ NVMe Minecraft & Discord Bot Hosting subscriptions and invoices.'
                : 'Real-time cryptographic audit log of actions performed on your account.'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => onSelectAccountTab('dashboard')}
            className="px-4 py-2 rounded-xl bg-red-950/50 border border-red-500/40 text-xs text-red-300 hover:bg-red-600/30 transition-colors"
          >
            ← Back to Dashboard
          </button>
        </div>

        {accountTab === 'billing' ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {[
              {
                title: 'Discord Bot NVMe Pro',
                audience: 'For 24/7 Node.js & Python Bots',
                price: '₹199 / mo',
                specs: '8 GB DDR5 ECC · 30 GB NVMe · 4 Ryzen vCores · Unmetered DDoS Protection',
              },
              {
                title: 'Minecraft Extreme Ryzen 9950X',
                audience: 'For High-TPS Paper/Purpur SMPs',
                price: '₹899 / mo',
                specs: '32 GB DDR5 ECC · 120 GB Gen5 NVMe · 8 Ryzen 9950X Cores · Dedicated Port',
              },
              {
                title: 'Hunter Custom EPYC Stock Plan',
                audience: 'For Large Networks & Proxies',
                price: 'Custom Dedicated',
                specs: '62.7 GB DDR5 · 146.5 GB NVMe · 10 AMD EPYC 9654 Cores · In-Node-25',
              },
            ].map((plan) => (
              <div
                key={plan.title}
                className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 hover:border-red-500/50 rounded-2xl p-6 flex flex-col justify-between space-y-4 transition-all"
              >
                <div className="space-y-2">
                  <div className="text-xs text-red-400 font-semibold">{plan.audience}</div>
                  <h3 className="text-lg font-display font-bold text-white">{plan.title}</h3>
                  <div className="text-2xl font-mono font-bold text-white">{plan.price}</div>
                  <p className="text-xs text-zinc-400 leading-relaxed">{plan.specs}</p>
                </div>
                <button
                  type="button"
                  onClick={onOpenDeployModal}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 text-xs font-semibold text-white shadow-[0_0_15px_rgba(139, 92, 246,0.3)] transition-all"
                >
                  Deploy Instance on Plan
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-[#0c0818]/85 backdrop-blur-xl border border-red-950/60 rounded-2xl divide-y divide-red-950/40">
            {[
              { event: 'server:console.command', desc: 'Executed command "tps" on Hunter Custom Stock Plan', ip: '103.195.102.25', time: '2 minutes ago' },
              { event: 'server:power.restart', desc: 'Triggered graceful restart on BulkBot Prime 🚀', ip: '15.235.180.14', time: '1 hour ago' },
              { event: 'auth:success', desc: 'Authenticated via Hardware 2FA Guard (hunterk.v)', ip: '49.37.218.14', time: '3 hours ago' },
              { event: 'server:backup.complete', desc: 'Completed Pre-Season-4-Reset-Snapshot (3.82 GB)', ip: '103.195.102.25', time: '7 hours ago' },
            ].map((act, idx) => (
              <div key={idx} className="p-4 flex items-center justify-between text-sm">
                <div>
                  <span className="font-mono text-xs text-red-400 font-semibold">{act.event}</span>
                  <div className="text-zinc-200 mt-0.5">{act.desc}</div>
                </div>
                <div className="text-right font-mono text-xs text-zinc-400">
                  <div>{act.ip}</div>
                  <div>{act.time}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  // MAIN PTERODACTYL DASHBOARD VIEW (Matches Reference Screenshot 1)
  return (
    <div
      className="px-6 lg:px-10 py-4 space-y-7 max-w-[1440px]"
    >
      {/* Welcome Header & BulkNode Banner Strip */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-[28px] font-display font-bold text-white tracking-tight">
            Welcome back, HUNTER
          </h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Manage all your instances here.
          </p>
        </div>

        {/* Sleek Branded Banner Pill showcasing BulkNode Logo + Fast & Reliable Hosting */}
        <div
          className="relative overflow-hidden rounded-2xl border border-red-500/40 px-5 py-3 flex items-center gap-4 shadow-[0_0_30px_rgba(139, 92, 246,0.22)]"
          style={{
            backgroundImage: `linear-gradient(to right, rgba(8, 5, 22, 0.92), rgba(88, 28, 160, 0.65)), url('/assets/aistudio/image_ae315672.png')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          <img
            src="/assets/aistudio/image_a5091caf.png"
            alt="BulkNode Emblem"
            referrerPolicy="no-referrer"
            className="w-10 h-10 object-contain rounded-lg shrink-0"
          />
          <div>
            <div className="text-xs font-display font-bold text-white tracking-wide">
              BᴜʟᴋNᴏᴅᴇ | ꜰᴀsᴛ &amp; ʀᴇʟɪᴀʙʟᴇ ʜᴏsᴛɪɴɢ 🚀
            </div>
            <div className="text-[11px] text-red-200/80 font-mono tabular-nums">
              AMD EPYC 9654 &amp; Ryzen 9950X Nodes · 17.2 Tbps DDoS Shield
            </div>
          </div>
        </div>
      </div>

      {/* 4 Quick Action Cards Row (Exact Match to Screenshot 1 with Red Theme) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Highlighted Crimson Discord Card */}
        <button
          type="button"
          onClick={() => onOpenExternalModal('discord')}
          className="text-left rounded-2xl p-5 bg-gradient-to-br from-red-500 via-red-600 to-red-900 border border-red-400/50 shadow-[0_10px_30px_rgba(139, 92, 246,0.35)] flex flex-col justify-between min-h-[132px] group cursor-pointer"
        >
          <div className="text-xs text-red-100/90 font-medium">
            Get help and talk to the community.
          </div>
          <div className="text-2xl font-display font-bold text-white tracking-tight my-1">
            Discord
          </div>
          <div className="inline-flex items-center gap-1 text-xs font-semibold text-white/95 group-hover:translate-x-1 transition-transform">
            <span>Visit</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </div>
        </button>

        {/* Card 2: Billing */}
        <button
          type="button"
          onClick={() => onSelectAccountTab('billing')}
          className="text-left rounded-2xl p-5 bg-[#110b22]/80 hover:bg-[#170f2a]/90 backdrop-blur-xl border border-red-950/60 hover:border-red-500/40 flex flex-col justify-between min-h-[132px] group transition-all cursor-pointer"
        >
          <div className="text-xs text-zinc-400 flex items-center gap-1.5">
            <CreditCard className="w-3.5 h-3.5 text-zinc-500" />
            <span>Invoices, plans and payment.</span>
          </div>
          <div className="text-2xl font-display font-bold text-white tracking-tight my-1">
            Billing
          </div>
          <div className="inline-flex items-center gap-1 text-xs font-semibold text-red-400 group-hover:text-red-300 group-hover:translate-x-1 transition-all">
            <span>Visit</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </div>
        </button>

        {/* Card 3: Website */}
        <button
          type="button"
          onClick={() => onOpenExternalModal('website')}
          className="text-left rounded-2xl p-5 bg-[#110b22]/80 hover:bg-[#170f2a]/90 backdrop-blur-xl border border-red-950/60 hover:border-red-500/40 flex flex-col justify-between min-h-[132px] group transition-all cursor-pointer"
        >
          <div className="text-xs text-zinc-400">
            Everything we host, and what it costs.
          </div>
          <div className="text-2xl font-display font-bold text-white tracking-tight my-1">
            Website
          </div>
          <div className="inline-flex items-center gap-1 text-xs font-semibold text-red-400 group-hover:text-red-300 group-hover:translate-x-1 transition-all">
            <span>Visit</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </div>
        </button>

        {/* Card 4: Contact support */}
        <button
          type="button"
          onClick={() => onOpenExternalModal('support')}
          className="text-left rounded-2xl p-5 bg-[#110b22]/80 hover:bg-[#170f2a]/90 backdrop-blur-xl border border-red-950/60 hover:border-red-500/40 flex flex-col justify-between min-h-[132px] group transition-all cursor-pointer"
        >
          <div className="text-xs text-zinc-400">
            Open a ticket with a human.
          </div>
          <div className="text-2xl font-display font-bold text-white tracking-tight my-1">
            Contact support
          </div>
          <div className="inline-flex items-center gap-1 text-xs font-semibold text-red-400 group-hover:text-red-300 group-hover:translate-x-1 transition-all">
            <span>Visit</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </div>
        </button>
      </div>

      {/* Your Servers Header + Category Filter Controls */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-display font-bold text-white">Your servers</h2>
            <p className="text-xs text-zinc-400">
              Everything on this account, with live usage.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Category Filter Segmented Control */}
            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#0b0716]/90 border border-red-950/60">
              <button
                type="button"
                onClick={() => setCategoryFilter('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                  categoryFilter === 'all'
                    ? 'bg-red-600 text-white shadow-[0_0_12px_rgba(139, 92, 246,0.4)]'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                All ({servers.length})
              </button>
              <button
                type="button"
                onClick={() => setCategoryFilter('minecraft')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all whitespace-nowrap ${
                  categoryFilter === 'minecraft'
                    ? 'bg-red-600 text-white shadow-[0_0_12px_rgba(139, 92, 246,0.4)]'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Gamepad2 className="w-3.5 h-3.5" />
                <span>Minecraft</span>
              </button>
              <button
                type="button"
                onClick={() => setCategoryFilter('bot')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all whitespace-nowrap ${
                  categoryFilter === 'bot'
                    ? 'bg-red-600 text-white shadow-[0_0_12px_rgba(139, 92, 246,0.4)]'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Bot className="w-3.5 h-3.5" />
                <span>Discord Bots</span>
              </button>
            </div>

            <button
              type="button"
              aria-label="Deploy New Server Instance"
              onClick={onOpenDeployModal}
              className="w-9 h-9 rounded-xl bg-[#0b0716]/90 hover:bg-red-950/60 border border-red-950/60 hover:border-red-500/50 flex items-center justify-center text-zinc-300 hover:text-red-400 transition-colors"
            >
              <FolderPlus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Server Rows List (Matches Screenshot 1 Horizontal Glass Bar) */}
        <div className="space-y-3">
          {filteredServers.map((server, index) => {
            const isRunning = server.status === 'RUNNING';
            const isOffline = server.status === 'OFFLINE';

            return (
              <div
                key={server.id}
                onClick={() => onSelectServer(server.id)}
                className="group bg-[#09061a]/90 hover:bg-[#14070b]/95 backdrop-blur-2xl border border-red-950/60 hover:border-red-500/50 rounded-2xl px-4 py-3.5 flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-[0_8px_30px_rgba(0,0,0,0.5)] transition-all cursor-pointer"
              >
                {/* Left: Status Indicator + BulkNode Hexagon Icon + Name & Hostname */}
                <div className="flex items-center gap-3.5 min-w-0">
                  <span
                    className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                      isRunning
                        ? 'bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]'
                        : isOffline
                        ? 'bg-red-500'
                        : 'bg-amber-400 animate-ping'
                    }`}
                  />
                  <div className="w-10 h-10 rounded-xl bg-black/90 border border-red-500/40 p-1 shrink-0 shadow-[0_0_15px_rgba(139, 92, 246,0.2)]">
                    <img
                      src="/assets/aistudio/image_a5091caf.png"
                      alt={server.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain rounded-lg"
                    />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2.5">
                      <span className="text-sm font-display font-bold text-white group-hover:text-red-400 transition-colors truncate">
                        {server.name}
                      </span>
                      <span className="text-[11px] text-zinc-400 hidden sm:inline">
                        · {server.category === 'minecraft' ? 'Minecraft' : 'Bot Hosting'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5 text-xs text-zinc-400 font-mono">
                      <span className="truncate">{server.hostname}</span>
                      <button
                        type="button"
                        aria-label={`Copy address for ${server.name}`}
                        onClick={(e) => handleCopy(server.hostname, server.id, e)}
                        className="text-zinc-500 hover:text-red-400 transition-colors"
                      >
                        {copiedId === server.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right: Node Flag + Memory + Disk + CPU + Sleek Red Manage Button */}
                <div className="flex flex-wrap items-center justify-between lg:justify-end gap-6 lg:gap-8">
                  <div className="flex items-center gap-6 sm:gap-8 font-mono tabular-nums">
                    <span className="text-base" title={server.node}>
                      {getFlag(server.countryCode)}
                    </span>

                    <div>
                      <div className="text-[11px] font-sans text-zinc-400">Memory</div>
                      <div className="text-xs font-semibold text-white">
                        {server.memoryUsedGB.toFixed(1)} GB{' '}
                        <span className="text-zinc-500 font-normal">
                          / {server.memoryLimitGB} GB
                        </span>
                      </div>
                    </div>

                    <div>
                      <div className="text-[11px] font-sans text-zinc-400">Disk</div>
                      <div className="text-xs font-semibold text-white">
                        {server.diskUsedGB.toFixed(1)} GB{' '}
                        <span className="text-zinc-500 font-normal">
                          / {server.diskLimitGB} GB
                        </span>
                      </div>
                    </div>

                    <div>
                      <div className="text-[11px] font-sans text-zinc-400">CPU</div>
                      <div className="text-xs font-semibold text-white">
                        {server.cpuPercent.toFixed(1)}%{' '}
                        <span className="text-zinc-500 font-normal">
                          / {server.cpuCores} cores
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectServer(server.id);
                    }}
                    className="px-4 py-2 rounded-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white text-xs font-semibold flex items-center gap-2 shadow-[0_0_20px_rgba(139, 92, 246,0.45)] transition-all cursor-pointer whitespace-nowrap"
                  >
                    <span>Manage</span>
                    <SlidersHorizontal className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer matching Pterodactyl style */}
      <footer className="pt-4 pb-8 text-[11px] text-zinc-400 space-y-0.5">
        <div>Pterodactyl® © 2015 - 2026</div>
        <div className="text-red-400/90 font-medium">
          Powered By BᴜʟᴋNᴏᴅᴇ | ꜰᴀsᴛ &amp; ʀᴇʟɪᴀʙʟᴇ ʜᴏsᴛɪɴɢ 🚀
        </div>
      </footer>
    </div>
  );
};
