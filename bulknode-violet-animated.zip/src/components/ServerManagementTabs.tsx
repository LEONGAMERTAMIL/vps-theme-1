import React, { useState } from 'react';
import {
  Folder,
  FileText,
  Plus,
  Save,
  Trash2,
  Download,
  Lock,
  Unlock,
  Check,
  RefreshCw,
  Database,
  Archive,
  Network,
  Calendar,
  Users,
  Globe,
  Puzzle,
  Layers,
  Rocket,
  Settings,
  Activity,
  Upload,
} from 'lucide-react';
import {
  ServerInstance,
  ServerFile,
  EGG_CATALOG,
  PLUGIN_CATALOG,
  PluginItem,
} from '../utils/panelLogic';
import { ServerTab } from './Sidebar';

interface ServerManagementTabsProps {
  server: ServerInstance;
  activeTab: ServerTab;
  onUpdateServer: (updated: ServerInstance) => void;
  onShowToast: (msg: string) => void;
}

export const ServerManagementTabs: React.FC<ServerManagementTabsProps> = ({
  server,
  activeTab,
  onUpdateServer,
  onShowToast,
}) => {
  // Files state
  const [editingFile, setEditingFile] = useState<ServerFile | null>(null);
  const [fileContent, setFileContent] = useState('');
  const [newFileName, setNewFileName] = useState('');
  const [deletedFiles, setDeletedFiles] = useState<ServerFile[]>([
    { name: 'old-crash-2026-10-19.txt', type: 'file', size: '18.4 KB', modified: '3 days ago' },
  ]);

  // Databases state
  const [newDbName, setNewDbName] = useState('');

  // Backups state
  const [newBackupName, setNewBackupName] = useState('');

  // Schedules state
  const [newScheduleName, setNewScheduleName] = useState('');
  const [newScheduleCron, setNewScheduleCron] = useState('0 */6 * * *');

  // Subusers state
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserRole, setNewUserRole] = useState('Moderator');

  // Subdomain state
  const [subdomainPrefix, setSubdomainPrefix] = useState(
    server.subdomain.split('.')[0] || 'play'
  );

  // Settings state
  const [serverNameInput, setServerNameInput] = useState(server.name);

  // Plugins state
  const [plugins, setPlugins] = useState<PluginItem[]>(PLUGIN_CATALOG);
  const [pluginSearch, setPluginSearch] = useState('');

  // Import state
  const [sftpHost, setSftpHost] = useState('');
  const [sftpUser, setSftpUser] = useState('');

  // 1. FILES MANAGER
  if (activeTab === 'files') {
    return (
      <div
        className="px-6 lg:px-10 py-4 space-y-5 max-w-[1440px]"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-display font-bold text-white">File Manager</h1>
            <p className="text-xs text-zinc-400 font-mono mt-0.5">
              /home/container · {server.files.length} items
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!newFileName.trim()) return;
              const created: ServerFile = {
                name: newFileName.trim(),
                type: 'file',
                size: '0.5 KB',
                modified: 'Just now',
                content: `# ${newFileName.trim()} created on BulkNode Panel\n`,
              };
              onUpdateServer({
                ...server,
                files: [...server.files, created],
              });
              setNewFileName('');
              onShowToast(`Created file ${created.name}`);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              placeholder="New file name (e.g. whitelist.json)"
              aria-label="New file name"
              className="bg-[#0c0818]/90 border border-red-950/70 focus:border-red-500 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 text-xs font-semibold text-white flex items-center gap-1.5 whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create File</span>
            </button>
          </form>
        </div>

        {editingFile ? (
          <div className="bg-[#0a0716]/95 border border-red-500/40 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="font-mono text-sm font-semibold text-red-400">
                /home/container/{editingFile.name}
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEditingFile(null)}
                  className="px-3.5 py-1.5 rounded-xl bg-zinc-900 text-xs text-zinc-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const updatedFiles = server.files.map((f) =>
                      f.name === editingFile.name
                        ? { ...f, content: fileContent, modified: 'Just now' }
                        : f
                    );
                    onUpdateServer({ ...server, files: updatedFiles });
                    setEditingFile(null);
                    onShowToast(`Saved changes to ${editingFile.name}`);
                  }}
                  className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-xs font-semibold text-white flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save File</span>
                </button>
              </div>
            </div>
            <textarea
              rows={12}
              value={fileContent}
              onChange={(e) => setFileContent(e.target.value)}
              className="w-full bg-black/80 border border-red-950/70 focus:border-red-500 rounded-xl p-4 font-mono text-xs text-zinc-100 focus:outline-none"
            />
          </div>
        ) : (
          <div className="bg-[#0c0818]/90 backdrop-blur-xl border border-red-950/60 rounded-2xl overflow-hidden divide-y divide-white/[0.05]">
            {server.files.map((file) => (
              <div
                key={file.name}
                onClick={() => {
                  if (file.type === 'file') {
                    setEditingFile(file);
                    setFileContent(
                      file.content || `# ${file.name}\n# Managed by BulkNode Hosting\n`
                    );
                  } else {
                    onShowToast(`Opened directory /home/container/${file.name}`);
                  }
                }}
                className="px-5 py-3 flex items-center justify-between hover:bg-red-600/10 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  {file.type === 'folder' ? (
                    <Folder className="w-4 h-4 text-red-400 fill-red-500/20" />
                  ) : (
                    <FileText className="w-4 h-4 text-zinc-400" />
                  )}
                  <span className="text-xs font-medium text-white">{file.name}</span>
                </div>

                <div className="flex items-center gap-6 text-xs font-mono text-zinc-400 tabular-nums">
                  <span>{file.size}</span>
                  <span className="hidden sm:inline">{file.modified}</span>
                  <button
                    type="button"
                    aria-label={`Delete ${file.name}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeletedFiles([file, ...deletedFiles]);
                      onUpdateServer({
                        ...server,
                        files: server.files.filter((f) => f.name !== file.name),
                      });
                      onShowToast(`Moved ${file.name} to Recycle Bin`);
                    }}
                    className="p-1 text-zinc-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  // 2. STARTUP VARIABLES
  if (activeTab === 'startup') {
    return (
      <div
        className="px-6 lg:px-10 py-4 space-y-5 max-w-[1440px]"
      >
        <div>
          <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
            <Rocket className="w-5 h-5 text-red-400" />
            <span>Startup Configuration</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Customize container startup flags, Docker image, and environment variables.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-[#0c0818]/90 border border-red-950/60 rounded-2xl p-5 space-y-2">
            <div className="text-xs font-semibold text-zinc-400">Startup Command</div>
            <div className="bg-black/70 border border-red-950/60 rounded-xl p-3.5 font-mono text-xs text-red-300 break-all">
              {server.startupCommand}
            </div>
          </div>

          <div className="bg-[#0c0818]/90 border border-red-950/60 rounded-2xl p-5 space-y-2">
            <div className="text-xs font-semibold text-zinc-400">Docker Container Image</div>
            <select
              value={server.dockerImage}
              onChange={(e) => {
                onUpdateServer({ ...server, dockerImage: e.target.value });
                onShowToast(`Updated container image to ${e.target.value}`);
              }}
              aria-label="Docker Image"
              className="w-full bg-black/70 border border-red-950/70 rounded-xl px-3 py-2.5 text-xs font-mono text-white focus:outline-none"
            >
              <option value="ghcr.io/pterodactyl/yolks:java_21">
                ghcr.io/pterodactyl/yolks:java_21
              </option>
              <option value="ghcr.io/pterodactyl/yolks:java_17">
                ghcr.io/pterodactyl/yolks:java_17
              </option>
              <option value="ghcr.io/pterodactyl/yolks:nodejs_22">
                ghcr.io/pterodactyl/yolks:nodejs_22
              </option>
              <option value="ghcr.io/pterodactyl/yolks:python_3.12">
                ghcr.io/pterodactyl/yolks:python_3.12
              </option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {server.variables.map((v) => (
            <div
              key={v.key}
              className="bg-[#0c0818]/90 border border-red-950/60 rounded-2xl p-5 space-y-3"
            >
              <div>
                <div className="text-sm font-display font-bold text-white">{v.name}</div>
                <div className="text-xs text-zinc-400 mt-0.5">{v.description}</div>
              </div>
              <input
                type="text"
                value={v.value}
                onChange={(e) => {
                  const updatedVars = server.variables.map((item) =>
                    item.key === v.key ? { ...item, value: e.target.value } : item
                  );
                  onUpdateServer({ ...server, variables: updatedVars });
                }}
                onBlur={() => onShowToast(`Updated ${v.key}`)}
                className="w-full bg-black/70 border border-red-950/70 focus:border-red-500 rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-none"
              />
              <div className="text-[11px] font-mono text-zinc-500">
                Env: {v.key} · {v.rules}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 3. SWITCH EGG (Minecraft & Discord Bot Egg Switcher)
  if (activeTab === 'switch-egg') {
    return (
      <div
        className="px-6 lg:px-10 py-4 space-y-5 max-w-[1440px]"
      >
        <div>
          <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-red-400" />
            <span>Switch Server Egg (Minecraft &amp; Discord Bot Runtimes)</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Hot-swap your instance between PaperMC, Purpur, Velocity Proxy, Discord.js, Python, or Lavalink v4.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {EGG_CATALOG.map((egg) => {
            const isCurrent = server.eggId === egg.id;
            return (
              <div
                key={egg.id}
                className={`rounded-2xl p-5 border flex flex-col justify-between space-y-4 transition-all ${
                  isCurrent
                    ? 'bg-gradient-to-br from-red-950/55 to-[#0c0818] border-red-500 shadow-[0_0_25px_rgba(139, 92, 246,0.25)]'
                    : 'bg-[#0c0818]/85 border-red-950/60 hover:border-red-500/40'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-mono text-red-400 uppercase">
                      {egg.category === 'minecraft' ? 'Minecraft Egg' : 'Discord Bot Egg'}
                    </span>
                    {isCurrent && (
                      <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Active Egg
                      </span>
                    )}
                  </div>
                  <h3 className="text-base font-display font-bold text-white">{egg.name}</h3>
                  <p className="text-xs text-zinc-400 leading-relaxed">{egg.description}</p>
                  <div className="text-[11px] font-mono text-zinc-500 truncate">
                    {egg.dockerImage}
                  </div>
                </div>

                <button
                  type="button"
                  disabled={isCurrent}
                  onClick={() => {
                    onUpdateServer({
                      ...server,
                      eggId: egg.id,
                      eggName: egg.name,
                      category: egg.category,
                      dockerImage: egg.dockerImage,
                      startupCommand: egg.startupCommand,
                    });
                    onShowToast(`Switched server egg to ${egg.name}`);
                  }}
                  className={`w-full py-2 rounded-xl text-xs font-semibold transition-all ${
                    isCurrent
                      ? 'bg-red-950/30 text-zinc-500 cursor-not-allowed'
                      : 'bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 text-white shadow-[0_0_15px_rgba(139, 92, 246,0.3)]'
                  }`}
                >
                  {isCurrent ? 'Currently Installed' : 'Apply Egg Configuration'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // 4. PLUGIN INSTALLER / BOT MODULES
  if (activeTab === 'plugins' || activeTab === 'version-changer') {
    const visiblePlugins = plugins.filter((p) =>
      pluginSearch.trim()
        ? p.name.toLowerCase().includes(pluginSearch.toLowerCase()) ||
          p.description.toLowerCase().includes(pluginSearch.toLowerCase())
        : true
    );

    return (
      <div
        className="px-6 lg:px-10 py-4 space-y-5 max-w-[1440px]"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
              {activeTab === 'plugins' ? (
                <Puzzle className="w-5 h-5 text-red-400" />
              ) : (
                <Layers className="w-5 h-5 text-red-400" />
              )}
              <span>
                {activeTab === 'plugins'
                  ? 'One-Click Plugin & Bot Module Installer'
                  : 'One-Click Version & Runtime Changer'}
              </span>
            </h1>
            <p className="text-xs text-zinc-400 mt-0.5">
              Direct Modrinth, SpigotMC, Hangar &amp; NPM Registry integration powered by BᴜʟᴋNᴏᴅᴇ.
            </p>
          </div>

          <input
            type="text"
            value={pluginSearch}
            onChange={(e) => setPluginSearch(e.target.value)}
            placeholder="Search plugins or bot packages..."
            aria-label="Search plugins"
            className="bg-[#0c0818]/90 border border-red-950/70 focus:border-red-500 rounded-xl px-4 py-2 text-xs text-white focus:outline-none w-full sm:w-64"
          />
        </div>

        {activeTab === 'version-changer' && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {['1.21.4 (Latest)', '1.21.1', '1.20.6', '1.20.4', '1.19.4', '1.18.2', '1.16.5', '1.8.8 PvP'].map(
              (ver) => (
                <button
                  key={ver}
                  type="button"
                  onClick={() =>
                    onShowToast(`Downloaded & verified ${ver} jar on ${server.name}`)
                  }
                  className="p-4 rounded-2xl bg-[#0c0818]/90 hover:bg-red-950/40 border border-red-950/60 hover:border-red-500/50 text-left transition-all"
                >
                  <div className="text-sm font-display font-bold text-white">{ver}</div>
                  <div className="text-[11px] text-red-400 mt-1">Install Build →</div>
                </button>
              )
            )}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {visiblePlugins.map((pl) => (
            <div
              key={pl.id}
              className="bg-[#0c0818]/90 border border-red-950/60 rounded-2xl p-5 flex items-start justify-between gap-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-display font-bold text-white">{pl.name}</span>
                  <span className="text-[11px] font-mono text-zinc-400">v{pl.version}</span>
                </div>
                <p className="text-xs text-zinc-400 leading-relaxed">{pl.description}</p>
                <div className="text-[11px] text-zinc-500 font-mono pt-1">
                  By {pl.author} · {pl.downloads} downloads
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setPlugins(
                    plugins.map((item) =>
                      item.id === pl.id ? { ...item, installed: !item.installed } : item
                    )
                  );
                  onShowToast(
                    pl.installed
                      ? `Removed ${pl.name} from /plugins`
                      : `Installed ${pl.name} v${pl.version} to container`
                  );
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold shrink-0 transition-all ${
                  pl.installed
                    ? 'bg-emerald-950/40 border border-emerald-500/40 text-emerald-400'
                    : 'bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 text-white'
                }`}
              >
                {pl.installed ? 'Installed ✓' : 'Install'}
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 5. DATABASES
  if (activeTab === 'databases') {
    return (
      <div
        className="px-6 lg:px-10 py-4 space-y-5 max-w-[1440px]"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
              <Database className="w-5 h-5 text-red-400" />
              <span>MySQL / MariaDB Databases</span>
            </h1>
            <p className="text-xs text-zinc-400 mt-0.5">
              Low-latency NVMe SQL databases hosted on {server.node}.
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!newDbName.trim()) return;
              const created = {
                id: `db-${Date.now()}`,
                name: `s${server.port}_${newDbName.trim().toLowerCase()}`,
                username: `u${server.port}_${Math.random().toString(36).slice(2, 7)}`,
                host: 'db-in25.bulknode.com:3306',
                connectionsFrom: '%',
                maxConnections: 100,
              };
              onUpdateServer({
                ...server,
                databases: [...server.databases, created],
              });
              setNewDbName('');
              onShowToast(`Created MySQL database ${created.name}`);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={newDbName}
              onChange={(e) => setNewDbName(e.target.value)}
              placeholder="Database name (e.g. economy)"
              aria-label="New database name"
              className="bg-[#0c0818]/90 border border-red-950/70 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-xs font-semibold text-white whitespace-nowrap"
            >
              + New Database
            </button>
          </form>
        </div>

        <div className="space-y-3">
          {server.databases.map((db) => (
            <div
              key={db.id}
              className="bg-[#0c0818]/90 border border-red-950/60 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1 font-mono text-xs">
                <div className="text-sm font-bold text-white">{db.name}</div>
                <div className="text-zinc-400">
                  Endpoint: <span className="text-red-400">{db.host}</span> · User:{' '}
                  <span className="text-zinc-200">{db.username}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  onUpdateServer({
                    ...server,
                    databases: server.databases.filter((item) => item.id !== db.id),
                  });
                  onShowToast(`Dropped database ${db.name}`);
                }}
                className="p-2 rounded-xl text-zinc-400 hover:text-red-400 hover:bg-red-950/40 self-end sm:self-center"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 6. BACKUPS
  if (activeTab === 'backups') {
    return (
      <div
        className="px-6 lg:px-10 py-4 space-y-5 max-w-[1440px]"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
              <Archive className="w-5 h-5 text-red-400" />
              <span>Off-Site NVMe Backups</span>
            </h1>
            <p className="text-xs text-zinc-400 mt-0.5">
              Instant SHA-256 verified container snapshots stored on BulkNode Object Storage.
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              const label = newBackupName.trim() || `Manual-Snapshot-${server.backups.length + 1}`;
              const created = {
                id: `bk-${Date.now()}`,
                name: label,
                size: `${(server.diskUsedGB * 0.62).toFixed(2)} GB`,
                createdAt: 'Just now',
                sha256: Math.random().toString(16).slice(2, 18),
                locked: false,
              };
              onUpdateServer({
                ...server,
                backups: [created, ...server.backups],
              });
              setNewBackupName('');
              onShowToast(`Created snapshot "${label}"`);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={newBackupName}
              onChange={(e) => setNewBackupName(e.target.value)}
              placeholder="Backup name..."
              aria-label="Backup name"
              className="bg-[#0c0818]/90 border border-red-950/70 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-xs font-semibold text-white whitespace-nowrap"
            >
              Create Backup
            </button>
          </form>
        </div>

        <div className="space-y-3">
          {server.backups.map((bk) => (
            <div
              key={bk.id}
              className="bg-[#0c0818]/90 border border-red-950/60 rounded-2xl p-4 flex items-center justify-between gap-4"
            >
              <div>
                <div className="text-sm font-semibold text-white flex items-center gap-2">
                  <span>{bk.name}</span>
                  {bk.locked && <Lock className="w-3.5 h-3.5 text-red-400" />}
                </div>
                <div className="text-xs font-mono text-zinc-400 mt-0.5">
                  {bk.size} · {bk.createdAt} · sha256:{bk.sha256}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onShowToast(`Restoring ${bk.name} to container...`)}
                  className="px-3 py-1.5 rounded-lg bg-red-950/40 border border-red-500/30 text-xs text-red-300 hover:bg-red-600/30"
                >
                  Restore
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 7. NETWORK / SUBDOMAINS / SCHEDULES / USERS / SETTINGS / RECYCLE BIN / IMPORT / ACTIVITY
  return (
    <div
      className="px-6 lg:px-10 py-4 space-y-5 max-w-[1440px]"
    >
      {activeTab === 'network' && (
        <>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
                <Network className="w-5 h-5 text-red-400" />
                <span>Network Allocations &amp; Ports</span>
              </h1>
              <p className="text-xs text-zinc-400 mt-0.5">
                Manage primary game port and extra ports for Voice Chat, GeyserMC, or BlueMap.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                const nextPort = 25575 + server.allocations.length;
                onUpdateServer({
                  ...server,
                  allocations: [
                    ...server.allocations,
                    {
                      id: `al-${Date.now()}`,
                      ip: server.ip,
                      alias: server.hostname.split(':')[0],
                      port: nextPort,
                      notes: 'Extra Plugin Port',
                      isPrimary: false,
                    },
                  ],
                });
                onShowToast(`Allocated port ${nextPort}`);
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-xs font-semibold text-white"
            >
              + Allocate Port
            </button>
          </div>
          <div className="space-y-3">
            {server.allocations.map((al) => (
              <div
                key={al.id}
                className="bg-[#0c0818]/90 border border-red-950/60 rounded-2xl p-4 flex items-center justify-between"
              >
                <div className="font-mono text-xs space-y-1">
                  <div className="text-sm font-bold text-white">
                    {al.alias}:{al.port}{' '}
                    {al.isPrimary && (
                      <span className="text-red-400 text-xs font-sans">· Primary</span>
                    )}
                  </div>
                  <div className="text-zinc-400">
                    IP: {al.ip} · {al.notes}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {activeTab === 'subdomains' && (
        <div className="bg-[#0c0818]/90 border border-red-950/60 rounded-2xl p-6 space-y-4 max-w-2xl">
          <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
            <Globe className="w-5 h-5 text-red-400" />
            <span>Free SRV Subdomain Manager</span>
          </h1>
          <p className="text-xs text-zinc-400">
            Create a custom `.bulknode.gg` SRV record so players can connect without typing the port.
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const full = `${subdomainPrefix.trim()}.bulknode.gg`;
              onUpdateServer({ ...server, subdomain: full });
              onShowToast(`Active SRV subdomain updated to ${full}`);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={subdomainPrefix}
              onChange={(e) => setSubdomainPrefix(e.target.value)}
              className="flex-1 bg-black/70 border border-red-950/70 rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-none"
            />
            <span className="text-xs font-mono text-zinc-400">.bulknode.gg</span>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-xs font-semibold text-white"
            >
              Update SRV
            </button>
          </form>
          <div className="text-xs font-mono text-red-400">
            Current Active Subdomain: {server.subdomain}
          </div>
        </div>
      )}

      {activeTab === 'schedules' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-red-400" />
              <span>Automated Cron Schedules</span>
            </h1>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!newScheduleName.trim()) return;
                onUpdateServer({
                  ...server,
                  schedules: [
                    ...server.schedules,
                    {
                      id: `sch-${Date.now()}`,
                      name: newScheduleName.trim(),
                      cron: newScheduleCron,
                      lastRun: 'Never',
                      nextRun: 'in 6 hours',
                      active: true,
                      tasksCount: 1,
                    },
                  ],
                });
                setNewScheduleName('');
                onShowToast('Created automated schedule');
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={newScheduleName}
                onChange={(e) => setNewScheduleName(e.target.value)}
                placeholder="Schedule name..."
                className="bg-[#0c0818]/90 border border-red-950/70 rounded-xl px-3 py-2 text-xs text-white"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-xs font-semibold text-white"
              >
                + Add Schedule
              </button>
            </form>
          </div>
          <div className="space-y-3">
            {server.schedules.map((s) => (
              <div
                key={s.id}
                className="bg-[#0c0818]/90 border border-red-950/60 rounded-2xl p-4 flex items-center justify-between"
              >
                <div>
                  <div className="text-sm font-bold text-white">{s.name}</div>
                  <div className="text-xs font-mono text-zinc-400">
                    Cron: {s.cron} · Next run {s.nextRun}
                  </div>
                </div>
                <span className="text-xs font-mono text-emerald-400">ACTIVE</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h1 className="text-xl font-display font-bold text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-red-400" />
              <span>Subusers &amp; Team Access</span>
            </h1>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!newUserEmail.trim()) return;
                onUpdateServer({
                  ...server,
                  subusers: [
                    ...server.subusers,
                    {
                      id: `usr-${Date.now()}`,
                      username: newUserEmail.split('@')[0],
                      email: newUserEmail.trim(),
                      role: newUserRole,
                      twoFactor: true,
                      permissions: 18,
                    },
                  ],
                });
                setNewUserEmail('');
                onShowToast(`Invited ${newUserEmail} to ${server.name}`);
              }}
              className="flex items-center gap-2"
            >
              <input
                type="email"
                value={newUserEmail}
                onChange={(e) => setNewUserEmail(e.target.value)}
                placeholder="teammate@bulknode.gg"
                className="bg-[#0c0818]/90 border border-red-950/70 rounded-xl px-3 py-2 text-xs text-white"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-xs font-semibold text-white"
              >
                Invite User
              </button>
            </form>
          </div>
          <div className="space-y-3">
            {server.subusers.map((u) => (
              <div
                key={u.id}
                className="bg-[#0c0818]/90 border border-red-950/60 rounded-2xl p-4 flex items-center justify-between"
              >
                <div>
                  <div className="text-sm font-bold text-white">
                    {u.username} <span className="text-xs text-red-400">· {u.role}</span>
                  </div>
                  <div className="text-xs font-mono text-zinc-400">
                    {u.email} · {u.permissions} permissions granted
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {(activeTab === 'settings' ||
        activeTab === 'activity' ||
        activeTab === 'recycle-bin' ||
        activeTab === 'import') && (
        <div className="bg-[#0c0818]/90 border border-red-950/60 rounded-2xl p-6 space-y-4 max-w-3xl">
          <h1 className="text-xl font-display font-bold text-white capitalize">
            {activeTab.replace('-', ' ')}
          </h1>
          {activeTab === 'settings' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!serverNameInput.trim()) return;
                onUpdateServer({ ...server, name: serverNameInput.trim() });
                onShowToast(`Renamed server to ${serverNameInput.trim()}`);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs text-zinc-400 mb-1">Server Display Name</label>
                <input
                  type="text"
                  value={serverNameInput}
                  onChange={(e) => setServerNameInput(e.target.value)}
                  className="w-full bg-black/70 border border-red-950/70 rounded-xl px-3.5 py-2 text-sm text-white"
                />
              </div>
              <div className="text-xs font-mono text-zinc-400">
                SFTP Launch Address: sftp://hunterk.v.{server.shortId}@{server.ip}:2022
              </div>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-xs font-semibold text-white"
              >
                Save Server Settings
              </button>
            </form>
          )}

          {activeTab === 'recycle-bin' && (
            <div className="space-y-3">
              <p className="text-xs text-zinc-400">
                Recover accidentally deleted world files or configs within 72 hours.
              </p>
              {deletedFiles.map((df) => (
                <div
                  key={df.name}
                  className="flex items-center justify-between p-3 rounded-xl bg-black/50 border border-red-950/40"
                >
                  <span className="text-xs font-mono text-white">{df.name}</span>
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateServer({ ...server, files: [...server.files, df] });
                      setDeletedFiles(deletedFiles.filter((f) => f.name !== df.name));
                      onShowToast(`Restored ${df.name} to /home/container`);
                    }}
                    className="px-3 py-1 rounded-lg bg-red-600/30 text-xs text-red-300"
                  >
                    Restore File
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'import' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                onShowToast(`Started SFTP migration from ${sftpHost || 'remote host'}`);
              }}
              className="space-y-3"
            >
              <p className="text-xs text-zinc-400">
                Migrate an existing Minecraft server or Discord bot directly via SFTP/Rsync.
              </p>
              <input
                type="text"
                value={sftpHost}
                onChange={(e) => setSftpHost(e.target.value)}
                placeholder="sftp://oldhost.example.com:2022"
                required
                className="w-full bg-black/70 border border-red-950/70 rounded-xl px-3.5 py-2 text-xs font-mono text-white"
              />
              <input
                type="text"
                value={sftpUser}
                onChange={(e) => setSftpUser(e.target.value)}
                placeholder="SFTP Username"
                required
                className="w-full bg-black/70 border border-red-950/70 rounded-xl px-3.5 py-2 text-xs font-mono text-white"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-800 text-xs font-semibold text-white"
              >
                Start Cloud Migration
              </button>
            </form>
          )}

          {activeTab === 'activity' && (
            <div className="space-y-2 text-xs font-mono text-zinc-300">
              <div className="p-3 rounded-xl bg-black/50">
                [Today 09:20] server:console.command — Executed by hunterk.v (103.195.102.25)
              </div>
              <div className="p-3 rounded-xl bg-black/50">
                [Today 04:00] server:backup.complete — Automated NVMe Snapshot verified
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
