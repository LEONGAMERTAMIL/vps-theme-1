import React, { useState } from 'react';
import {
  LayoutGrid,
  User,
  Key,
  Terminal,
  Activity,
  MessageSquare,
  CreditCard,
  Globe,
  LifeBuoy,
  ChevronLeft,
  ChevronDown,
  Play,
  RotateCw,
  Square,
  Power,
  Search,
  FolderOpen,
  Rocket,
  Settings,
  Database,
  Archive,
  Network,
  Calendar,
  Users,
  RefreshCw,
  Trash2,
  Download,
  Puzzle,
  Layers,
  Loader2,
} from 'lucide-react';
import { ServerInstance } from '../utils/panelLogic';

export type AccountTab = 'dashboard' | 'account-overview' | 'api-credentials' | 'ssh-keys' | 'account-activity' | 'billing';
export type ServerTab =
  | 'overview'
  | 'console'
  | 'files'
  | 'startup'
  | 'settings'
  | 'databases'
  | 'backups'
  | 'network'
  | 'schedules'
  | 'users'
  | 'activity'
  | 'switch-egg'
  | 'subdomains'
  | 'recycle-bin'
  | 'import'
  | 'plugins'
  | 'version-changer';

interface SidebarProps {
  activeServer: ServerInstance | null;
  accountTab: AccountTab;
  serverTab: ServerTab;
  onSelectAccountTab: (tab: AccountTab) => void;
  onSelectServerTab: (tab: ServerTab) => void;
  onBackToDashboard: () => void;
  onPowerAction: (action: 'start' | 'restart' | 'stop' | 'kill') => void;
  onOpenExternalModal: (modal: 'discord' | 'billing' | 'website' | 'support') => void;
  powerLoading: 'start' | 'restart' | 'stop' | 'kill' | null;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeServer,
  accountTab,
  serverTab,
  onSelectAccountTab,
  onSelectServerTab,
  onBackToDashboard,
  onPowerAction,
  onOpenExternalModal,
  powerLoading,
}) => {
  const [sectionSearch, setSectionSearch] = useState('');
  const [accountOpen, setAccountOpen] = useState(true);
  const [linksOpen, setLinksOpen] = useState(true);
  const [managementOpen, setManagementOpen] = useState(true);
  const [utilsOpen, setUtilsOpen] = useState(true);

  const essentialItems: { id: ServerTab; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'Overview', icon: <LayoutGrid className="w-4 h-4" /> },
    { id: 'console', label: 'Console', icon: <Terminal className="w-4 h-4" /> },
    { id: 'files', label: 'Files', icon: <FolderOpen className="w-4 h-4" /> },
    { id: 'startup', label: 'Startup', icon: <Rocket className="w-4 h-4" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
  ];

  const managementItems: { id: ServerTab; label: string; icon: React.ReactNode }[] = [
    { id: 'databases', label: 'Databases', icon: <Database className="w-4 h-4" /> },
    { id: 'backups', label: 'Backups', icon: <Archive className="w-4 h-4" /> },
    { id: 'network', label: 'Network', icon: <Network className="w-4 h-4" /> },
    { id: 'schedules', label: 'Schedules', icon: <Calendar className="w-4 h-4" /> },
    { id: 'users', label: 'Users', icon: <Users className="w-4 h-4" /> },
    { id: 'activity', label: 'Activity', icon: <Activity className="w-4 h-4" /> },
    { id: 'switch-egg', label: 'Switch egg', icon: <RefreshCw className="w-4 h-4" /> },
    { id: 'subdomains', label: 'Subdomains', icon: <Globe className="w-4 h-4" /> },
    { id: 'recycle-bin', label: 'Recycle Bin', icon: <Trash2 className="w-4 h-4" /> },
    { id: 'import', label: 'Import', icon: <Download className="w-4 h-4" /> },
  ];

  const utilItems: { id: ServerTab; label: string; icon: React.ReactNode }[] = [
    {
      id: 'plugins',
      label: activeServer?.category === 'bot' ? 'Bot Modules' : 'Plugin Installer',
      icon: <Puzzle className="w-4 h-4" />,
    },
    {
      id: 'version-changer',
      label: activeServer?.category === 'bot' ? 'Runtime Switcher' : 'Version Changer',
      icon: <Layers className="w-4 h-4" />,
    },
  ];

  const filterList = <T extends { label: string }>(items: T[]) => {
    if (!sectionSearch.trim()) return items;
    return items.filter((item) =>
      item.label.toLowerCase().includes(sectionSearch.trim().toLowerCase())
    );
  };

  const isRunning = activeServer?.status === 'RUNNING';
  const isOffline = activeServer?.status === 'OFFLINE';
  const isTransitioning =
    activeServer?.status === 'STARTING' ||
    activeServer?.status === 'STOPPING' ||
    activeServer?.status === 'RESTARTING';

  return (
    <aside className="w-64 shrink-0 h-screen sticky top-0 bg-[#08051a]/90 backdrop-blur-xl border-r border-red-950/50 flex flex-col justify-between z-30 select-none">
      {/* Top Brand Lockup */}
      <div className="flex flex-col flex-1 min-h-0">
        <div className="px-4 pt-4 pb-3 border-b border-red-950/40">
          <button
            type="button"
            onClick={onBackToDashboard}
            className="flex items-center gap-3 w-full text-left group focus:outline-none"
          >
            <div className="relative w-10 h-10 rounded-xl overflow-hidden bg-black/80 border border-red-500/40 p-0.5 shrink-0 shadow-[0_0_15px_rgba(139, 92, 246,0.3)] group-hover:border-red-400 transition-colors">
              <img
                src="/assets/aistudio/image_a5091caf.png"
                alt="BulkNode Logo"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain rounded-lg"
              />
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-display font-bold text-base tracking-wide text-white truncate group-hover:text-red-400 transition-colors">
                BᴜʟᴋNᴏᴅᴇ
              </div>
              <div className="text-[11px] text-red-300/80 font-medium truncate">
                ꜰᴀsᴛ &amp; ʀᴇʟɪᴀʙʟᴇ ʜᴏsᴛɪɴɢ 🚀
              </div>
            </div>
          </button>
        </div>

        {/* Navigation Content */}
        {!activeServer ? (
          /* ACCOUNT / DASHBOARD MODE */
          <div className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
            <div>
              <button
                type="button"
                onClick={() => onSelectAccountTab('dashboard')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all whitespace-nowrap ${
                  accountTab === 'dashboard'
                    ? 'bg-gradient-to-r from-red-600/35 to-red-900/20 text-red-400 border border-red-500/40 shadow-[0_0_20px_rgba(139, 92, 246,0.2)]'
                    : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04]'
                }`}
              >
                <LayoutGrid className="w-4 h-4 shrink-0" />
                <span>Dashboard</span>
              </button>
            </div>

            {/* ACCOUNT SECTION */}
            <div>
              <button
                type="button"
                onClick={() => setAccountOpen(!accountOpen)}
                className="w-full flex items-center justify-between px-2 py-1 text-[11px] font-semibold tracking-wider text-zinc-500 hover:text-zinc-300 transition-colors"
              >
                <span>Account</span>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform ${accountOpen ? '' : '-rotate-90'}`}
                />
              </button>
              {accountOpen && (
                <div className="mt-1.5 space-y-1">
                  <button
                    type="button"
                    onClick={() => onSelectAccountTab('account-overview')}
                    className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-lg text-sm transition-colors whitespace-nowrap ${
                      accountTab === 'account-overview'
                        ? 'bg-red-600/25 text-red-400 font-medium border border-red-500/30'
                        : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04]'
                    }`}
                  >
                    <User className="w-4 h-4 shrink-0" />
                    <span>Overview</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSelectAccountTab('api-credentials')}
                    className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-lg text-sm transition-colors whitespace-nowrap ${
                      accountTab === 'api-credentials'
                        ? 'bg-red-600/25 text-red-400 font-medium border border-red-500/30'
                        : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04]'
                    }`}
                  >
                    <Key className="w-4 h-4 shrink-0" />
                    <span>API Credentials</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSelectAccountTab('ssh-keys')}
                    className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-lg text-sm transition-colors whitespace-nowrap ${
                      accountTab === 'ssh-keys'
                        ? 'bg-red-600/25 text-red-400 font-medium border border-red-500/30'
                        : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04]'
                    }`}
                  >
                    <Terminal className="w-4 h-4 shrink-0" />
                    <span>SSH Keys</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSelectAccountTab('account-activity')}
                    className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-lg text-sm transition-colors whitespace-nowrap ${
                      accountTab === 'account-activity'
                        ? 'bg-red-600/25 text-red-400 font-medium border border-red-500/30'
                        : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04]'
                    }`}
                  >
                    <Activity className="w-4 h-4 shrink-0" />
                    <span>Activity</span>
                  </button>
                </div>
              )}
            </div>

            {/* LINKS SECTION */}
            <div>
              <button
                type="button"
                onClick={() => setLinksOpen(!linksOpen)}
                className="w-full flex items-center justify-between px-2 py-1 text-[11px] font-semibold tracking-wider text-zinc-500 hover:text-zinc-300 transition-colors"
              >
                <span>Links</span>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform ${linksOpen ? '' : '-rotate-90'}`}
                />
              </button>
              {linksOpen && (
                <div className="mt-1.5 space-y-1">
                  <button
                    type="button"
                    onClick={() => onOpenExternalModal('discord')}
                    className="w-full flex items-center gap-3 px-3.5 py-2 rounded-lg text-sm text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04] transition-colors whitespace-nowrap"
                  >
                    <MessageSquare className="w-4 h-4 shrink-0 text-red-400" />
                    <span>Discord</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSelectAccountTab('billing')}
                    className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-lg text-sm transition-colors whitespace-nowrap ${
                      accountTab === 'billing'
                        ? 'bg-red-600/25 text-red-400 font-medium border border-red-500/30'
                        : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04]'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 shrink-0 text-red-400" />
                    <span>Billing</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenExternalModal('website')}
                    className="w-full flex items-center gap-3 px-3.5 py-2 rounded-lg text-sm text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04] transition-colors whitespace-nowrap"
                  >
                    <Globe className="w-4 h-4 shrink-0 text-red-400" />
                    <span>Website</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenExternalModal('support')}
                    className="w-full flex items-center gap-3 px-3.5 py-2 rounded-lg text-sm text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04] transition-colors whitespace-nowrap"
                  >
                    <LifeBuoy className="w-4 h-4 shrink-0 text-red-400" />
                    <span>Contact support</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* SERVER INSTANCE MODE (Matches Reference Screenshot 2 & 3) */
          <div className="flex-1 overflow-y-auto px-3 py-3 space-y-4">
            {/* Back to Dashboard + Server Header + Quick Power Controls */}
            <div className="space-y-3">
              <button
                type="button"
                onClick={onBackToDashboard}
                className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-red-400 transition-colors px-1"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>Dashboard</span>
              </button>

              <div className="flex items-center gap-2.5 px-1">
                <span
                  className={`w-2 h-2 rounded-full shrink-0 ${
                    isRunning
                      ? 'bg-emerald-400'
                      : isTransitioning
                      ? 'bg-amber-400 animate-ping'
                      : 'bg-red-500'
                  }`}
                />
                <div className="w-7 h-7 rounded-lg bg-black/80 border border-red-500/40 p-0.5 shrink-0">
                  <img
                    src="/assets/aistudio/image_a5091caf.png"
                    alt={activeServer.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain rounded"
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-semibold text-white truncate">
                    {activeServer.name}
                  </div>
                  <div className="text-[11px] text-zinc-400 truncate">
                    {activeServer.node}
                  </div>
                </div>
              </div>

              {/* 4 Circular Quick Power Controls */}
              <div className="grid grid-cols-4 gap-2 pt-0.5">
                <button
                  type="button"
                  aria-label="Sidebar Start Server"
                  disabled={isRunning || powerLoading !== null}
                  onClick={() => onPowerAction('start')}
                  className={`h-8 rounded-full flex items-center justify-center border transition-all ${
                    isRunning
                      ? 'border-emerald-500/30 bg-emerald-950/20 text-emerald-400/50 cursor-not-allowed'
                      : 'border-emerald-500/60 bg-emerald-950/40 text-emerald-400 hover:bg-emerald-600/30'
                  }`}
                >
                  {powerLoading === 'start' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Play className="w-3.5 h-3.5" />
                  )}
                </button>
                <button
                  type="button"
                  aria-label="Sidebar Restart Server"
                  disabled={powerLoading !== null}
                  onClick={() => onPowerAction('restart')}
                  className="h-8 rounded-full flex items-center justify-center border border-amber-500/50 bg-amber-950/30 text-amber-400 hover:bg-amber-600/30 transition-all"
                >
                  {powerLoading === 'restart' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <RotateCw className="w-3.5 h-3.5" />
                  )}
                </button>
                <button
                  type="button"
                  aria-label="Sidebar Stop Server"
                  disabled={isOffline || powerLoading !== null}
                  onClick={() => onPowerAction('stop')}
                  className={`h-8 rounded-full flex items-center justify-center border transition-all ${
                    isOffline
                      ? 'border-red-900/30 bg-red-950/10 text-red-500/40 cursor-not-allowed'
                      : 'border-red-500/60 bg-red-950/40 text-red-400 hover:bg-red-600/35'
                  }`}
                >
                  {powerLoading === 'stop' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Square className="w-3.5 h-3.5" />
                  )}
                </button>
                <button
                  type="button"
                  aria-label="Sidebar Kill Server"
                  disabled={isOffline || powerLoading !== null}
                  onClick={() => onPowerAction('kill')}
                  className="h-8 rounded-full flex items-center justify-center border border-zinc-700/80 bg-zinc-900/70 text-zinc-300 hover:border-red-500 hover:text-red-400 transition-all"
                >
                  <Power className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Search Sections Input */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={sectionSearch}
                  onChange={(e) => setSectionSearch(e.target.value)}
                  placeholder="Search sections"
                  aria-label="Search sections"
                  className="w-full bg-black/50 border border-red-950/60 focus:border-red-500/60 rounded-lg pl-8 pr-3 py-1.5 text-xs text-zinc-200 placeholder:text-zinc-500 focus:outline-none transition-colors"
                />
              </div>
            </div>

            {/* ESSENTIALS */}
            <div>
              <div className="px-2 py-1 text-[11px] font-semibold tracking-wider text-zinc-500">
                Essentials
              </div>
              <div className="mt-1 space-y-0.5">
                {filterList(essentialItems).map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onSelectServerTab(item.id)}
                    className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-sm transition-all whitespace-nowrap ${
                      serverTab === item.id
                        ? 'bg-gradient-to-r from-red-600/35 to-red-900/20 text-red-400 font-semibold border border-red-500/40 shadow-[0_0_15px_rgba(139, 92, 246,0.2)]'
                        : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04]'
                    }`}
                  >
                    <span className="shrink-0">{item.icon}</span>
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* MANAGEMENT */}
            <div>
              <button
                type="button"
                onClick={() => setManagementOpen(!managementOpen)}
                className="w-full flex items-center justify-between px-2 py-1 text-[11px] font-semibold tracking-wider text-zinc-500 hover:text-zinc-300 transition-colors"
              >
                <span>Management</span>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform ${managementOpen ? '' : '-rotate-90'}`}
                />
              </button>
              {managementOpen && (
                <div className="mt-1 space-y-0.5">
                  {filterList(managementItems).map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => onSelectServerTab(item.id)}
                      className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-sm transition-all whitespace-nowrap ${
                        serverTab === item.id
                          ? 'bg-gradient-to-r from-red-600/35 to-red-900/20 text-red-400 font-semibold border border-red-500/40 shadow-[0_0_15px_rgba(139, 92, 246,0.2)]'
                          : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04]'
                      }`}
                    >
                      <span className="shrink-0">{item.icon}</span>
                      <span>{item.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* MC UTILS / BOT UTILS */}
            <div>
              <button
                type="button"
                onClick={() => setUtilsOpen(!utilsOpen)}
                className="w-full flex items-center justify-between px-2 py-1 text-[11px] font-semibold tracking-wider text-zinc-500 hover:text-zinc-300 transition-colors"
              >
                <span>{activeServer.category === 'bot' ? 'Bot Utils' : 'MC Utils'}</span>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform ${utilsOpen ? '' : '-rotate-90'}`}
                />
              </button>
              {utilsOpen && (
                <div className="mt-1 space-y-0.5">
                  {filterList(utilItems).map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => onSelectServerTab(item.id)}
                      className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-sm transition-all whitespace-nowrap ${
                        serverTab === item.id
                          ? 'bg-gradient-to-r from-red-600/35 to-red-900/20 text-red-400 font-semibold border border-red-500/40 shadow-[0_0_15px_rgba(139, 92, 246,0.2)]'
                          : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.04]'
                      }`}
                    >
                      <span className="shrink-0">{item.icon}</span>
                      <span>{item.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Bottom User Profile Bar */}
      <div className="p-3 border-t border-red-950/50 bg-black/40">
        <button
          type="button"
          onClick={() => {
            onBackToDashboard();
            onSelectAccountTab('account-overview');
          }}
          className="w-full flex items-center gap-3 p-1.5 rounded-xl hover:bg-white/[0.04] transition-colors text-left"
        >
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-red-600 to-red-900 flex items-center justify-center text-white font-bold text-xs shadow-[0_0_12px_rgba(139, 92, 246,0.4)] shrink-0">
            H
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-xs font-semibold text-zinc-100 truncate">hunterk.v</div>
            <div className="text-[11px] text-zinc-500 truncate">contactallsaved@ga...</div>
          </div>
        </button>
      </div>
    </aside>
  );
};
