/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CheckCircle2, Menu, X } from 'lucide-react';
import {
  INITIAL_SERVERS,
  ServerInstance,
  transitionPowerState,
  executeConsoleCommand,
  incrementUptime,
} from './utils/panelLogic';
import { Sidebar, AccountTab, ServerTab } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { DashboardView } from './components/DashboardView';
import { ServerOverviewAndConsole } from './components/ServerOverviewAndConsole';
import { ServerManagementTabs } from './components/ServerManagementTabs';
import {
  DeployServerModal,
  ExternalInfoModal,
} from './components/DeployAndCommunityModals';

export default function App() {
  const [servers, setServers] = useState<ServerInstance[]>(INITIAL_SERVERS);
  const [selectedServerId, setSelectedServerId] = useState<string | null>(null);
  const [accountTab, setAccountTab] = useState<AccountTab>('dashboard');
  const [serverTab, setServerTab] = useState<ServerTab>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [powerLoading, setPowerLoading] = useState<
    'start' | 'restart' | 'stop' | 'kill' | null
  >(null);
  const [deployModalOpen, setDeployModalOpen] = useState(false);
  const [externalModal, setExternalModal] = useState<
    'discord' | 'billing' | 'website' | 'support' | null
  >(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const activeServer =
    servers.find((s) => s.id === selectedServerId) || null;

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => setToastMessage(null), 3200);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  // Live telemetry & uptime updates for running servers
  useEffect(() => {
    const interval = setInterval(() => {
      setServers((prev) =>
        prev.map((srv) => {
          if (srv.status !== 'RUNNING') return srv;
          const deltaCpu = (Math.random() - 0.48) * 0.6;
          const nextCpu = Math.max(
            0.8,
            Math.min(srv.cpuCores * 100, Number((srv.cpuPercent + deltaCpu).toFixed(1)))
          );
          const nextNetOut = Math.max(
            120,
            Math.round(srv.netOutBps + (Math.random() - 0.5) * 140)
          );
          return {
            ...srv,
            uptime: incrementUptime(srv.uptime, 1),
            cpuPercent: nextCpu,
            cpuHistory: [...srv.cpuHistory.slice(1), nextCpu],
            netOutBps: nextNetOut,
            netHistory: [...srv.netHistory.slice(1), nextNetOut],
          };
        })
      );
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleSelectServer = (serverId: string) => {
    setSelectedServerId(serverId);
    setServerTab('overview');
    setMobileMenuOpen(false);
  };

  const handleBackToDashboard = () => {
    setSelectedServerId(null);
    setAccountTab('dashboard');
    setMobileMenuOpen(false);
  };

  const handlePowerAction = (action: 'start' | 'restart' | 'stop' | 'kill') => {
    if (!activeServer) return;
    setPowerLoading(action);
    const transition = transitionPowerState(activeServer.status, action);
    const nowTime = new Date().toTimeString().slice(0, 8);

    // Immediate intermediate state
    setServers((prev) =>
      prev.map((srv) =>
        srv.id === activeServer.id
          ? {
              ...srv,
              status: transition.intermediateStatus,
              logs: [
                ...srv.logs,
                {
                  id: `pwr-${Date.now()}-1`,
                  timestamp: nowTime,
                  level: 'INFO',
                  source: 'BulkNode-Wings',
                  message: `Power signal [${action.toUpperCase()}] received by container daemon...`,
                },
              ],
            }
          : srv
      )
    );

    setTimeout(() => {
      const doneTime = new Date().toTimeString().slice(0, 8);
      setServers((prev) =>
        prev.map((srv) =>
          srv.id === activeServer.id
            ? {
                ...srv,
                status: transition.finalStatus,
                uptime:
                  transition.finalStatus === 'OFFLINE'
                    ? '0s'
                    : action === 'restart' || action === 'start'
                    ? '1s'
                    : srv.uptime,
                logs: [
                  ...srv.logs,
                  {
                    id: `pwr-${Date.now()}-2`,
                    timestamp: doneTime,
                    level: 'INFO',
                    source: 'BulkNode-Wings',
                    message: transition.systemMessage,
                  },
                ],
              }
            : srv
        )
      );
      setPowerLoading(null);
      showToast(`${activeServer.name}: ${transition.systemMessage}`);
    }, 550);
  };

  const handleSendCommand = (cmd: string) => {
    if (!activeServer) return;
    const newEntries = executeConsoleCommand(activeServer, cmd);
    if (!newEntries.length) return;
    setServers((prev) =>
      prev.map((srv) =>
        srv.id === activeServer.id
          ? { ...srv, logs: [...srv.logs, ...newEntries] }
          : srv
      )
    );
  };

  const handleUpdateServer = (updated: ServerInstance) => {
    setServers((prev) =>
      prev.map((srv) => (srv.id === updated.id ? updated : srv))
    );
  };

  return (
    <div className="min-h-screen w-full bg-[#06040f] text-zinc-100 flex relative overflow-x-hidden">
      {/* Animated violet aurora background */}
      <div aria-hidden="true" className="fixed inset-0 z-0 pointer-events-none vault-bg">
        <div className="aurora aurora-a" />
        <div className="aurora aurora-b" />
        <div className="aurora aurora-c" />
        <div className="grid-drift" />
      </div>

      {/* Desktop Left Sidebar */}
      <div className="hidden md:block z-30">
        <Sidebar
          activeServer={activeServer}
          accountTab={accountTab}
          serverTab={serverTab}
          onSelectAccountTab={(tab) => {
            setSelectedServerId(null);
            setAccountTab(tab);
          }}
          onSelectServerTab={(tab) => setServerTab(tab)}
          onBackToDashboard={handleBackToDashboard}
          onPowerAction={handlePowerAction}
          onOpenExternalModal={(m) =>
            m === 'billing' ? setAccountTab('billing') : setExternalModal(m)
          }
          powerLoading={powerLoading}
        />
      </div>

      {/* Mobile Drawer Sidebar */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-black/75 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative z-10 animate-fade-in">
            <Sidebar
              activeServer={activeServer}
              accountTab={accountTab}
              serverTab={serverTab}
              onSelectAccountTab={(tab) => {
                setSelectedServerId(null);
                setAccountTab(tab);
                setMobileMenuOpen(false);
              }}
              onSelectServerTab={(tab) => {
                setServerTab(tab);
                setMobileMenuOpen(false);
              }}
              onBackToDashboard={handleBackToDashboard}
              onPowerAction={handlePowerAction}
              onOpenExternalModal={(m) => {
                setMobileMenuOpen(false);
                if (m === 'billing') setAccountTab('billing');
                else setExternalModal(m);
              }}
              powerLoading={powerLoading}
            />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 relative z-10">
        {/* Mobile Top Header Trigger */}
        <div className="md:hidden flex items-center justify-between px-4 pt-3 pb-1">
          <button
            type="button"
            aria-label="Toggle navigation menu"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl bg-[#100a22]/90 border border-red-950/70 text-zinc-200"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <div className="flex items-center gap-2">
            <img
              src="/assets/aistudio/image_a5091caf.png"
              alt="BulkNode"
              referrerPolicy="no-referrer"
              className="w-6 h-6 rounded"
            />
            <span className="font-display font-bold text-sm text-white">
              BᴜʟᴋNᴏᴅᴇ 🚀
            </span>
          </div>
        </div>

        {/* Top Search & Utility Bar */}
        <TopBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          servers={servers}
          onSelectServer={handleSelectServer}
          onOpenDeployModal={() => setDeployModalOpen(true)}
          onOpenExternalModal={(m) => setExternalModal(m)}
          onShowToast={showToast}
        />

        {/* Main Viewport */}
        <main className="flex-1">
          {!activeServer ? (
            <DashboardView
              servers={servers}
              searchQuery={searchQuery}
              accountTab={accountTab}
              onSelectServer={handleSelectServer}
              onSelectAccountTab={setAccountTab}
              onOpenDeployModal={() => setDeployModalOpen(true)}
              onOpenExternalModal={(m) => setExternalModal(m)}
              onShowToast={showToast}
            />
          ) : serverTab === 'overview' || serverTab === 'console' ? (
            <ServerOverviewAndConsole
              server={activeServer}
              mode={serverTab}
              onPowerAction={handlePowerAction}
              powerLoading={powerLoading}
              onSendCommand={handleSendCommand}
              onShowToast={showToast}
              onUpdateServer={handleUpdateServer}
            />
          ) : (
            <ServerManagementTabs
              server={activeServer}
              activeTab={serverTab}
              onUpdateServer={handleUpdateServer}
              onShowToast={showToast}
            />
          )}
        </main>
      </div>

      {/* Deploy New Instance Modal */}
      <DeployServerModal
        isOpen={deployModalOpen}
        onClose={() => setDeployModalOpen(false)}
        onDeploySuccess={(newSrv) => {
          setServers((prev) => [newSrv, ...prev]);
          setDeployModalOpen(false);
          setSelectedServerId(newSrv.id);
          setServerTab('overview');
          showToast(`Deployed ${newSrv.name} on ${newSrv.node}!`);
        }}
      />

      {/* Community / Support / Website Modal */}
      <ExternalInfoModal
        modalType={externalModal}
        onClose={() => setExternalModal(null)}
        onShowToast={showToast}
      />

      {/* Sleek Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-[#140609]/95 backdrop-blur-2xl border border-red-500/50 text-xs font-medium text-white shadow-[0_10px_30px_rgba(139, 92, 246,0.35)] animate-fade-up">
          <CheckCircle2 className="w-4 h-4 text-red-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
